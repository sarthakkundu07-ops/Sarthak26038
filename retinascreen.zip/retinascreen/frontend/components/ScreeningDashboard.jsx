"use client";
import { useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  AlertTriangle, CloudOff, CloudUpload, CheckCircle2, SplitSquareHorizontal, Eye, FileDown, Hospital, Info, Layers, Printer,
} from "lucide-react";
import { LANGUAGES, setLanguage } from "../lib/i18n";

/**
 * Props
 *  result     : response of POST /api/screenings/infer (or the cached copy from IndexedDB)
 *  patientLabel: short label shown on screen, e.g. "Ramesh K., 54 y"
 *  eye        : "LEFT" | "RIGHT" (known from the capture step; the infer response does not echo it)
 *  screeningId: server id, used for the PDF export (may be null while offline)
 *  syncState  : "pending" | "synced" | "needs_attention"
 *  online     : boolean (navigator.onLine)
 *  apiFetch   : (url, init) => Promise<Response> with auth attached
 *  onRefer    : (risk) => void  opens the referral form / routing flow
 */

// Stage styling. Colour is never the only signal: each stage also has a number and a text label.
const STAGE_STYLE = {
  0: { fill: "bg-emerald-700", ring: "ring-emerald-700", text: "text-emerald-800" },
  1: { fill: "bg-amber-700", ring: "ring-amber-700", text: "text-amber-800" },
  2: { fill: "bg-orange-700", ring: "ring-orange-700", text: "text-orange-800" },
  3: { fill: "bg-red-700", ring: "ring-red-700", text: "text-red-800" },
  4: { fill: "bg-rose-950", ring: "ring-rose-950", text: "text-rose-950" },
};

export default function ScreeningDashboard({
  result, patientLabel, eye, screeningId, syncState = "pending", online = true, apiFetch, onRefer,
}) {
  const { t, i18n } = useTranslation();
  const [view, setView] = useState("focus");
  const [exporting, setExporting] = useState(false);
  const [exportError, setExportError] = useState(null);

  const { stage, confidence, explainability: xai, risk } = result;
  const style = STAGE_STYLE[stage];
  const pct = Math.round(confidence * 100);
  const urgent = risk.tier === "IMMEDIATE_48H";
  const originalSrc = `data:image/jpeg;base64,${xai.original_jpeg_base64}`;
  const overlaySrc = `data:image/jpeg;base64,${xai.overlay_jpeg_base64}`;

  const dueLabel = useMemo(
    () => risk.due_by
      ? t("referBy", { date: new Intl.DateTimeFormat(i18n.language, { dateStyle: "medium" }).format(new Date(risk.due_by)) })
      : null,
    [risk.due_by, i18n.language, t]
  );

  async function exportPdf() {
    setExportError(null);
    // Offline or not yet synced: fall back to the browser's print dialog (print stylesheet hides controls).
    if (!online || !screeningId) { window.print(); return; }
    setExporting(true);
    try {
      const res = await apiFetch(`/api/screenings/${screeningId}/report.pdf?lang=${i18n.language}`);
      if (!res.ok) throw new Error(String(res.status));
      const url = URL.createObjectURL(await res.blob());
      const a = Object.assign(document.createElement("a"), { href: url, download: `dr-report-${screeningId}.pdf` });
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 10_000);
    } catch {
      setExportError(t("cta.exportFailed"));
    } finally {
      setExporting(false);
    }
  }

  return (
    <main className="mx-auto max-w-5xl bg-slate-50 px-4 pb-32 pt-3 font-sans text-slate-900 md:px-6">
      {/* Top bar: who, which eye, sync state, language */}
      <header className="flex flex-wrap items-center justify-between gap-2 py-2">
        <div>
          <p className="text-lg font-bold">{patientLabel}</p>
          {eye && <p className="text-base text-slate-700">{t(`result.eye.${eye}`)}</p>}
        </div>
        <div className="flex items-center gap-2 print:hidden">
          <SyncChip state={syncState} online={online} t={t} />
          <label className="sr-only" htmlFor="lang">Language</label>
          <select
            id="lang" value={i18n.language}
            onChange={(e) => setLanguage(e.target.value)}
            className="h-12 rounded-lg border-2 border-slate-400 bg-white px-3 text-base font-medium focus:outline-none focus-visible:ring-4 focus-visible:ring-blue-600"
          >
            {LANGUAGES.map((l) => <option key={l.code} value={l.code}>{l.label}</option>)}
          </select>
        </div>
      </header>

      {/* Disclaimer: always visible, never dismissible, present in print output too */}
      <div role="note" className="my-2 flex gap-3 rounded-lg border-l-8 border-blue-800 bg-blue-50 p-3 text-base leading-snug text-blue-950">
        <Info className="mt-0.5 h-6 w-6 shrink-0" aria-hidden />
        <p>{t("disclaimer")}</p>
      </div>

      <div className="mt-3 grid gap-4 md:grid-cols-[minmax(0,3fr)_minmax(0,2fr)]">
        {/* ---------- Image panel ---------- */}
        <section aria-label={t("view.label")} className="rounded-xl bg-white p-3 shadow-sm ring-1 ring-slate-200">
          <div role="tablist" aria-label={t("view.label")} className="mb-3 flex gap-2 print:hidden">
            <ViewTab id="original" current={view} set={setView} icon={Eye} label={t("view.original")} />
            <ViewTab id="focus" current={view} set={setView} icon={Layers} label={t("view.focus")} />
            <ViewTab id="side" current={view} set={setView} icon={SplitSquareHorizontal} label={t("view.side")} className="hidden md:flex" />
          </div>

          {view === "side" ? (
            <div className="grid grid-cols-2 gap-2">
              <Fundus src={originalSrc} alt={t("view.original")} caption={t("view.original")} />
              <Fundus src={overlaySrc} alt={t("view.focus")} caption={t("view.focus")} />
            </div>
          ) : (
            <Fundus src={view === "original" ? originalSrc : overlaySrc} alt={t(`view.${view}`)} />
          )}
          {view !== "original" && <p className="mt-2 text-base text-slate-700">{t("focusNote")}</p>}
        </section>

        {/* ---------- Result + referral panel ---------- */}
        <section className="flex flex-col gap-4">
          <div className="rounded-xl bg-white p-4 shadow-sm ring-1 ring-slate-200">
            <p className="text-base font-semibold text-slate-700">{t("result.stage")}</p>
            <div className="mt-1 flex items-center gap-3">
              <span
                className={`flex h-16 w-16 items-center justify-center rounded-2xl text-4xl font-extrabold text-white ${style.fill}`}
                aria-hidden
              >{stage}</span>
              <p className={`text-2xl font-bold leading-tight ${style.text}`}>{t(`stage.${stage}`)}</p>
            </div>

            {/* Five-step severity scale: current stage is filled, the rest are outlined */}
            <ol className="mt-4 flex gap-1" aria-label={t("result.stage")}>
              {[0, 1, 2, 3, 4].map((s) => (
                <li key={s} aria-current={s === stage ? "step" : undefined}
                  className={`flex h-9 flex-1 items-center justify-center rounded-md text-base font-bold ${
                    s === stage ? `${STAGE_STYLE[s].fill} text-white` : "border-2 border-slate-300 text-slate-600"}`}>
                  {s}
                </li>
              ))}
            </ol>

            <div className="mt-4">
              <div className="flex items-baseline justify-between">
                <span className="text-base font-semibold text-slate-700">{t("result.confidence")}</span>
                <span className="text-xl font-bold">{pct}%</span>
              </div>
              <div className="mt-1 h-3 overflow-hidden rounded-full bg-slate-200" role="progressbar"
                aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}>
                <div className="h-full bg-slate-800" style={{ width: `${pct}%` }} />
              </div>
            </div>

            {result.low_confidence && (
              <p className="mt-3 flex gap-2 rounded-lg bg-amber-100 p-3 text-base font-medium text-amber-950">
                <AlertTriangle className="h-6 w-6 shrink-0" aria-hidden />{t("result.lowConfidence")}
              </p>
            )}
          </div>

          <div className={`rounded-xl p-4 ring-2 ${urgent ? "bg-red-50 ring-red-700" : "bg-white ring-slate-200"}`}>
            <p className={`text-xl font-bold ${urgent ? "text-red-900" : "text-slate-900"}`}>{t(`tier.${risk.tier}`)}</p>
            {dueLabel && <p className="mt-1 text-base font-medium text-slate-800">{dueLabel}</p>}
            <p className="mt-2 text-base text-slate-800">{t(`action.${risk.action_code}`)}</p>
          </div>
        </section>
      </div>

      {/* ---------- Sticky action bar (thumb reach) ---------- */}
      <div className="fixed inset-x-0 bottom-0 z-10 border-t border-slate-300 bg-white/95 p-3 backdrop-blur print:hidden">
        <div className="mx-auto flex max-w-5xl flex-col gap-2 sm:flex-row">
          {risk.refer && (
            <button type="button" onClick={() => onRefer?.(risk)}
              className={`flex min-h-14 flex-1 items-center justify-center gap-2 rounded-xl px-4 text-lg font-bold text-white focus:outline-none focus-visible:ring-4 focus-visible:ring-blue-600 ${urgent ? "bg-red-700 active:bg-red-800" : "bg-blue-800 active:bg-blue-900"}`}>
              <Hospital className="h-6 w-6" aria-hidden />{t(`action.${risk.action_code}`)}
            </button>
          )}
          <button type="button" onClick={exportPdf} disabled={exporting}
            className="flex min-h-14 flex-1 items-center justify-center gap-2 rounded-xl border-2 border-slate-700 bg-white px-4 text-lg font-bold text-slate-900 focus:outline-none focus-visible:ring-4 focus-visible:ring-blue-600 disabled:opacity-60 sm:max-w-xs">
            {online && screeningId ? <FileDown className="h-6 w-6" aria-hidden /> : <Printer className="h-6 w-6" aria-hidden />}
            {exporting ? t("cta.exporting") : online && screeningId ? t("cta.exportPdf") : t("cta.printOffline")}
          </button>
        </div>
        {exportError && <p role="alert" className="mx-auto mt-2 max-w-5xl text-base font-medium text-red-800">{exportError}</p>}
      </div>
    </main>
  );
}

function Fundus({ src, alt, caption }) {
  return (
    <figure>
      {/* Fixed square box prevents layout shift on slow image decode */}
      <img src={src} alt={alt} className="aspect-square w-full rounded-lg bg-black object-contain" />
      {caption && <figcaption className="mt-1 text-center text-base font-medium text-slate-700">{caption}</figcaption>}
    </figure>
  );
}

function ViewTab({ id, current, set, icon: Icon, label, className = "flex" }) {
  const active = current === id;
  return (
    <button type="button" role="tab" aria-selected={active} onClick={() => set(id)}
      className={`${className} min-h-12 flex-1 items-center justify-center gap-2 rounded-lg px-3 text-base font-bold focus:outline-none focus-visible:ring-4 focus-visible:ring-blue-600 ${
        active ? "bg-slate-900 text-white" : "border-2 border-slate-300 bg-white text-slate-800"}`}>
      <Icon className="h-5 w-5" aria-hidden />{label}
    </button>
  );
}

function SyncChip({ state, online, t }) {
  const cfg = !online
    ? { Icon: CloudOff, cls: "bg-slate-200 text-slate-900", label: t("sync.offline") }
    : state === "synced"
      ? { Icon: CheckCircle2, cls: "bg-emerald-100 text-emerald-950", label: t("sync.synced") }
      : { Icon: CloudUpload, cls: "bg-amber-100 text-amber-950", label: t("sync.pending") };
  return (
    <span className={`flex min-h-12 items-center gap-2 rounded-full px-3 text-base font-semibold ${cfg.cls}`} role="status">
      <cfg.Icon className="h-5 w-5" aria-hidden />{cfg.label}
    </span>
  );
}
