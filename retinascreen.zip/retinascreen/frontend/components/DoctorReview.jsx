"use client";
import { useCallback, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { AlertTriangle, CheckCircle2, Info, Loader2, ThumbsDown, ThumbsUp, HelpCircle } from "lucide-react";

/**
 * Tele-ophthalmology review workspace.
 * Queue (urgent first, least-confident AI first) -> image comparison -> verdict form.
 * Every submission is stored as a new clinical_audits row; earlier reviews are superseded, never deleted.
 * Props: apiFetch(url, init) with auth attached.
 */

const STAGE_FILL = ["bg-emerald-700", "bg-amber-700", "bg-orange-700", "bg-red-700", "bg-rose-950"];
const isoDate = (d) => d.toISOString().slice(0, 10);
const addDays = (n) => { const d = new Date(); d.setDate(d.getDate() + n); return isoDate(d); };

export default function DoctorReview({ apiFetch }) {
  const { t } = useTranslation();
  const [queue, setQueue] = useState(null);       // null = loading
  const [selectedId, setSelectedId] = useState(null);
  const [detail, setDetail] = useState(null);
  const [error, setError] = useState(null);

  const loadQueue = useCallback(async () => {
    try {
      const r = await apiFetch("/api/review/queue");
      if (!r.ok) throw new Error();
      const { items } = await r.json();
      setQueue(items);
      setSelectedId((cur) => cur ?? items[0]?.id ?? null);
    } catch { setError("Could not load the queue. Pull to retry."); setQueue([]); }
  }, [apiFetch]);

  useEffect(() => { loadQueue(); }, [loadQueue]);

  useEffect(() => {
    if (!selectedId) { setDetail(null); return; }
    let cancelled = false;
    setDetail(null);
    apiFetch(`/api/screenings/${selectedId}`)
      .then((r) => (r.ok ? r.json() : Promise.reject()))
      .then((d) => { if (!cancelled) setDetail(d); })
      .catch(() => { if (!cancelled) setError("Could not open this screening."); });
    return () => { cancelled = true; };
  }, [selectedId, apiFetch]);

  function onSaved(id) {
    const rest = (queue ?? []).filter((x) => x.id !== id);
    setQueue(rest);
    setSelectedId(rest[0]?.id ?? null);
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <div role="note" className="flex gap-2 border-b border-blue-200 bg-blue-50 px-4 py-2 text-base text-blue-950">
        <Info className="h-5 w-5 shrink-0" aria-hidden /><p>{t("disclaimer")}</p>
      </div>
      {error && <p role="alert" className="bg-red-50 px-4 py-2 text-base font-medium text-red-900">{error}</p>}

      <div className="grid gap-4 p-4 lg:grid-cols-[280px_minmax(0,1fr)_360px]">
        {/* Queue */}
        <nav aria-label={t("doctor.queue")} className="rounded-xl bg-white p-2 ring-1 ring-slate-200 lg:max-h-[calc(100vh-6rem)] lg:overflow-y-auto">
          <h2 className="px-2 py-2 text-lg font-bold">{t("doctor.queue")} {queue && `(${queue.length})`}</h2>
          {queue === null && <Loader2 className="m-4 h-6 w-6 animate-spin" aria-label="Loading" />}
          {queue?.length === 0 && <p className="p-3 text-base text-slate-700">{t("doctor.empty")}</p>}
          <ul className="flex gap-2 overflow-x-auto lg:block lg:space-y-1 lg:overflow-visible">
            {queue?.map((q) => (
              <li key={q.id} className="shrink-0 lg:shrink">
                <button type="button" onClick={() => setSelectedId(q.id)} aria-current={q.id === selectedId}
                  className={`flex min-h-14 w-full items-center gap-3 rounded-lg px-3 text-left focus:outline-none focus-visible:ring-4 focus-visible:ring-blue-600 ${
                    q.id === selectedId ? "bg-slate-900 text-white" : "hover:bg-slate-100"}`}>
                  <span className={`flex h-10 w-10 items-center justify-center rounded-lg text-xl font-extrabold text-white ${STAGE_FILL[q.dr_stage]}`}>{q.dr_stage}</span>
                  <span className="text-base">
                    <span className="block font-bold">{Math.round(Number(q.confidence) * 100)}%</span>
                    <span className={`block ${q.risk_tier === "IMMEDIATE_48H" ? "font-bold text-red-500" : ""}`}>{t(`tier.${q.risk_tier}`)}</span>
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </nav>

        {/* Images */}
        <section className="rounded-xl bg-white p-3 ring-1 ring-slate-200">
          {!detail ? (
            <p className="p-8 text-center text-base text-slate-600">{selectedId ? <Loader2 className="mx-auto h-6 w-6 animate-spin" /> : t("doctor.empty")}</p>
          ) : (
            <>
              <div className="grid gap-3 sm:grid-cols-2">
                <figure>
                  <img alt={t("view.original")} className="aspect-square w-full rounded-lg bg-black object-contain"
                    src={`data:image/jpeg;base64,${detail.explainability.original_jpeg_base64}`} />
                  <figcaption className="mt-1 text-center text-base font-medium">{t("view.original")}</figcaption>
                </figure>
                <figure>
                  <img alt={t("view.focus")} className="aspect-square w-full rounded-lg bg-black object-contain"
                    src={`data:image/jpeg;base64,${detail.explainability.overlay_jpeg_base64}`} />
                  <figcaption className="mt-1 text-center text-base font-medium">{t("view.focus")}</figcaption>
                </figure>
              </div>
              <p className="mt-2 text-base text-slate-700">{t("focusNote")}</p>
              <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-1 rounded-lg bg-slate-100 p-3 text-base">
                <dt className="font-semibold">{t("doctor.aiSaid")}</dt>
                <dd>{detail.stage} · {t(`stage.${detail.stage}`)} · {Math.round(detail.confidence * 100)}%</dd>
                <dt className="font-semibold">{t("doctor.hba1c")}</dt><dd>{detail.context.hba1c_percent ?? "n/a"}</dd>
                <dt className="font-semibold">{t("doctor.duration")}</dt>
                <dd>{detail.context.duration_years != null ? `${detail.context.duration_years} ${t("doctor.years")}` : "n/a"}</dd>
                <dt className="font-semibold">{t("doctor.insulin")}</dt>
                <dd>{detail.context.on_insulin == null ? "n/a" : detail.context.on_insulin ? t("doctor.yes") : t("doctor.no")}</dd>
              </dl>
            </>
          )}
        </section>

        {/* Verdict form */}
        {detail && <VerdictForm key={detail.id} detail={detail} apiFetch={apiFetch} onSaved={onSaved} />}
      </div>
    </div>
  );
}

function VerdictForm({ detail, apiFetch, onSaved }) {
  const { t } = useTranslation();
  const [verdict, setVerdict] = useState(null);
  const [doctorStage, setDoctorStage] = useState(null);
  const [heatmapUseful, setHeatmapUseful] = useState(null);
  const [notes, setNotes] = useState("");
  const [followup, setFollowup] = useState("");
  const [state, setState] = useState({ busy: false, saved: false, error: null });

  const needsGrade = verdict === "DISAGREE" && doctorStage == null;
  const canSubmit = verdict && !needsGrade && !state.busy;

  async function submit(e) {
    e.preventDefault();
    if (!canSubmit) return;
    setState({ busy: true, saved: false, error: null });
    try {
      const r = await apiFetch(`/api/screenings/${detail.id}/audit`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          verdict, doctor_stage: verdict === "DISAGREE" ? doctorStage : null,
          heatmap_useful: heatmapUseful, notes: notes.trim() || null, next_followup_date: followup || null,
        }),
      });
      if (!r.ok) {
        const body = await r.json().catch(() => ({}));
        throw new Error(body?.detail?.message ?? "Could not save. Try again.");
      }
      setState({ busy: false, saved: true, error: null });
      setTimeout(() => onSaved(detail.id), 900);
    } catch (err) {
      setState({ busy: false, saved: false, error: err.message });
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4 rounded-xl bg-white p-4 ring-1 ring-slate-200">
      <fieldset>
        <legend className="mb-2 text-lg font-bold">{t("doctor.verdict")}</legend>
        <div className="grid gap-2">
          <Choice checked={verdict === "AGREE"} onSelect={() => setVerdict("AGREE")} icon={ThumbsUp} label={t("doctor.agree")} tone="emerald" />
          <Choice checked={verdict === "DISAGREE"} onSelect={() => setVerdict("DISAGREE")} icon={ThumbsDown} label={t("doctor.disagree")} tone="red" />
          <Choice checked={verdict === "UNGRADABLE"} onSelect={() => setVerdict("UNGRADABLE")} icon={HelpCircle} label={t("doctor.ungradable")} tone="slate" />
        </div>
      </fieldset>

      {verdict === "DISAGREE" && (
        <fieldset>
          <legend className="mb-2 text-base font-bold">{t("doctor.yourGrade")}</legend>
          <div className="grid grid-cols-5 gap-2">
            {[0, 1, 2, 3, 4].map((s) => (
              <button key={s} type="button" aria-pressed={doctorStage === s} onClick={() => setDoctorStage(s)}
                className={`min-h-14 rounded-lg text-xl font-extrabold focus:outline-none focus-visible:ring-4 focus-visible:ring-blue-600 ${
                  doctorStage === s ? `${STAGE_FILL[s]} text-white` : "border-2 border-slate-400 bg-white"}`}>{s}</button>
            ))}
          </div>
          {needsGrade && <p className="mt-2 flex gap-2 text-base font-medium text-amber-900"><AlertTriangle className="h-5 w-5 shrink-0" aria-hidden />{t("doctor.needGrade")}</p>}
        </fieldset>
      )}

      <fieldset>
        <legend className="mb-2 text-base font-bold">{t("doctor.heatmapUseful")}</legend>
        <div className="grid grid-cols-2 gap-2">
          {[[true, t("doctor.yes")], [false, t("doctor.no")]].map(([val, label]) => (
            <button key={String(val)} type="button" aria-pressed={heatmapUseful === val} onClick={() => setHeatmapUseful(val)}
              className={`min-h-12 rounded-lg text-base font-bold focus:outline-none focus-visible:ring-4 focus-visible:ring-blue-600 ${
                heatmapUseful === val ? "bg-slate-900 text-white" : "border-2 border-slate-400 bg-white"}`}>{label}</button>
          ))}
        </div>
      </fieldset>

      <div>
        <label htmlFor="notes" className="mb-1 block text-base font-bold">{t("doctor.notes")}</label>
        <textarea id="notes" rows={4} maxLength={4000} value={notes} onChange={(e) => setNotes(e.target.value)}
          className="w-full rounded-lg border-2 border-slate-400 p-3 text-base focus:outline-none focus-visible:ring-4 focus-visible:ring-blue-600" />
      </div>

      <fieldset>
        <legend className="mb-2 text-base font-bold">{t("doctor.followup")}</legend>
        <div className="grid grid-cols-3 gap-2">
          {[[t("doctor.in1w"), 7], [t("doctor.in1m"), 30], [t("doctor.in3m"), 90]].map(([label, days]) => (
            <button key={days} type="button" aria-pressed={followup === addDays(days)} onClick={() => setFollowup(addDays(days))}
              className={`min-h-12 rounded-lg text-base font-bold focus:outline-none focus-visible:ring-4 focus-visible:ring-blue-600 ${
                followup === addDays(days) ? "bg-slate-900 text-white" : "border-2 border-slate-400 bg-white"}`}>{label}</button>
          ))}
        </div>
        <input type="date" aria-label={t("doctor.custom")} min={isoDate(new Date())} value={followup} onChange={(e) => setFollowup(e.target.value)}
          className="mt-2 min-h-12 w-full rounded-lg border-2 border-slate-400 px-3 text-base focus:outline-none focus-visible:ring-4 focus-visible:ring-blue-600" />
      </fieldset>

      {state.error && <p role="alert" className="text-base font-medium text-red-800">{state.error}</p>}
      {state.saved && <p role="status" className="flex items-center gap-2 text-base font-bold text-emerald-800"><CheckCircle2 className="h-5 w-5" aria-hidden />{t("doctor.saved")}</p>}

      <button type="submit" disabled={!canSubmit}
        className="flex min-h-14 w-full items-center justify-center gap-2 rounded-xl bg-blue-800 text-lg font-bold text-white focus:outline-none focus-visible:ring-4 focus-visible:ring-blue-600 disabled:bg-slate-400">
        {state.busy && <Loader2 className="h-5 w-5 animate-spin" aria-hidden />}{state.busy ? t("doctor.saving") : t("doctor.submit")}
      </button>
    </form>
  );
}

function Choice({ checked, onSelect, icon: Icon, label, tone }) {
  const on = { emerald: "border-emerald-700 bg-emerald-50", red: "border-red-700 bg-red-50", slate: "border-slate-700 bg-slate-100" }[tone];
  return (
    <label className={`flex min-h-14 cursor-pointer items-center gap-3 rounded-lg border-2 px-3 text-base font-bold ${checked ? on : "border-slate-300 bg-white"} focus-within:ring-4 focus-within:ring-blue-600`}>
      <input type="radio" name="verdict" checked={checked} onChange={onSelect} className="h-5 w-5" />
      <Icon className="h-5 w-5" aria-hidden />{label}
    </label>
  );
}
