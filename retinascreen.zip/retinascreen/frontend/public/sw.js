/* Minimal offline-first service worker (no build step needed).
   - App shell and static assets: cache-first, refreshed in the background.
   - Navigations: network-first with cached fallback so the app opens with no signal.
   - API calls are never cached here. Offline data lives in IndexedDB (see lib/db.js).
   - Background Sync: wakes a client (or the page's own sync engine) when connectivity returns. */
const VERSION = "v1";
const SHELL = `shell-${VERSION}`;
const PRECACHE = ["/", "/screen", "/review", "/offline.html", "/manifest.webmanifest", "/fonts/NotoSans-subset.woff2"];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(SHELL).then((c) => c.addAll(PRECACHE)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== SHELL).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (e) => {
  const req = e.request;
  const url = new URL(req.url);
  if (req.method !== "GET" || url.pathname.startsWith("/api/")) return;

  if (req.mode === "navigate") {
    e.respondWith(
      fetch(req)
        .then((res) => { const copy = res.clone(); caches.open(SHELL).then((c) => c.put(req, copy)); return res; })
        .catch(() => caches.match(req).then((r) => r || caches.match("/offline.html")))
    );
    return;
  }
  // Static assets (_next/static is content-hashed, so cache-first is safe)
  e.respondWith(
    caches.match(req).then((hit) => {
      const network = fetch(req).then((res) => {
        if (res.ok) caches.open(SHELL).then((c) => c.put(req, res.clone()));
        return res;
      }).catch(() => hit);
      return hit || network;
    })
  );
});

self.addEventListener("sync", (e) => {
  if (e.tag === "sync-outbox") {
    e.waitUntil(
      self.clients.matchAll({ includeUncontrolled: true }).then((clients) => {
        clients.forEach((c) => c.postMessage("sync-outbox"));
      })
    );
  }
});
