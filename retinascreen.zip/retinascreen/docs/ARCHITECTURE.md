# RetinaScreen: Rural-first Explainable DR Screening Platform

Working name for the SIH prototype. Everything here is a decision-support aid. It does not diagnose. Clinical thresholds must be validated by a practising ophthalmologist before any real-world use.

## 1. System architecture

```mermaid
flowchart LR
  subgraph Field["Field device (low-spec Android, PWA)"]
    UI["Next.js PWA UI (i18n: en / hi / bn)"]
    SW["Service Worker (app shell + model assets cache)"]
    IDB[("IndexedDB via Dexie: patients, screenings, images, outbox")]
    QC["Optional on-device pre-check (canvas blur/brightness)"]
    UI <--> IDB
    UI --> QC
    SW --- UI
  end

  subgraph Cloud["Cloud / district data centre"]
    GW["Nginx / API gateway (TLS, gzip, rate limit)"]
    API["FastAPI (async)"]
    ML["Inference worker: ONNX Runtime (classify) + PyTorch (Grad-CAM)"]
    PG[("PostgreSQL: pgcrypto, row-level audit")]
    OBJ[("Object store: fundus JPEG + heatmap")]
    Q["Redis + worker: SMS / WhatsApp reminders"]
    GW --> API
    API --> ML
    API --> PG
    API --> OBJ
    API --> Q
  end

  UI -- "HTTPS, batch sync (Background Sync)" --> GW
  Doctor["Ophthalmologist web dashboard"] --> GW
  Admin["District admin dashboard"] --> GW
  Q --> WA["SMS gateway / WhatsApp Business API"]
```

### Design principles for low bandwidth

- App shell, fonts (Noto Sans with Devanagari, Bengali, Tamil subsets) and locale JSON are precached. After first load the app works with no network.
- Fundus images are compressed on device before upload: longest side 1024 px, JPEG quality 80, about 150 to 300 KB. Full-resolution originals stay in IndexedDB until confirmed synced, then are evicted (keep the last N).
- Sync is chunked and resumable. Images upload individually with a byte-range friendly endpoint, while metadata goes in small JSON batches.
- Inference is server-side by default because Grad-CAM needs gradients. If a screening is created offline, the worker still sees a client-side quality check and can record the visit. The AI result and heatmap appear after sync (typically seconds once online). An optional ONNX-Web (WASM) grade-only model can be shipped later for instant offline triage, clearly labelled "preliminary".

## 2. Workflow and state machine

```
DRAFT -> CAPTURED -> QC_PASSED | QC_FAILED(retake)
      -> QUEUED_FOR_SYNC -> SYNCED -> AI_COMPLETE
      -> REFERRAL_ISSUED -> DOCTOR_REVIEWED -> FOLLOWUP_SCHEDULED -> CLOSED
```

Each screening carries `status`, and the client shows a sync chip per record (Pending, Syncing, Synced, Needs attention).

## 3. Offline sync sequence

```mermaid
sequenceDiagram
  autonumber
  participant W as ASHA worker (PWA)
  participant DB as IndexedDB (Dexie)
  participant SW as Service Worker
  participant API as FastAPI /sync
  participant PG as PostgreSQL
  participant ML as Inference

  W->>DB: Save patient + consent + vitals (client_uuid, local version)
  W->>DB: Save fundus Blob (compressed) + on-device QC result
  DB->>DB: Append to outbox {entity, client_uuid, op, base_version, field_ts}
  Note over W,SW: Connectivity returns (online event or Background Sync tag "sync-outbox")
  SW->>API: POST /api/screenings/sync (batch of up to 20 ops, Idempotency-Key)
  API->>PG: Upsert by client_uuid inside a transaction
  API->>PG: Field-level merge or flag conflict
  API->>ML: Enqueue inference for screenings without result
  ML->>PG: Store stage, confidence, heatmap key, referral tier
  API-->>SW: per-record result {status, server_id, server_version, merged_fields, ai_result?}
  SW->>DB: Mark outbox rows done, write server_version, cache AI result
  DB-->>W: UI updates chip to Synced, heatmap becomes viewable
```

### Image handling

1. Capture returns a `Blob`. Store it as a Blob in IndexedDB (not base64: base64 costs about 33% more space and memory).
2. During sync the image is sent as `multipart/form-data` (also Blob, not base64). Base64 is used only for the heatmap overlay in API responses, so JSON stays self-contained for offline caching.
3. The server verifies a SHA-256 supplied by the client. A mismatch triggers an automatic re-upload, and a match on an existing hash makes the upload a no-op (idempotent).

## 4. Conflict resolution

Screenings are append-only clinical events, so most conflicts are avoided by design. Patients are the only genuinely mutable entity.

| Data | Who can edit | Strategy |
|---|---|---|
| Screening (image, vitals at visit) | Worker who created it | Immutable after sync. Corrections create an amendment record linked to the original. |
| AI result (stage, confidence, heatmap) | Server only | Server authoritative. Client fields are ignored. |
| Doctor review and referral status | Doctor only | Server authoritative. Never overwritten by worker edits. |
| Patient demographics and diabetes profile | Workers (several may share a patient) | Field-level last-writer-wins using per-field timestamps (`field_ts`), with the server clock as tiebreaker. |
| Consent | Worker with the patient present | Append-only ledger ordered by when the patient decided (capture time), not sync time. A late-syncing offline grant cannot override an earlier withdrawal. On exact ties, withdrawal wins. |
| Clinical safety fields (allergies, insulin use, HbA1c) | Workers | No silent overwrite. If both sides changed, keep the newer value, store the older in `conflict_log`, and show a "Confirm value" prompt to the next worker. |

Mechanics:

- Every mutable row has `version` (int, server-incremented) and `field_ts` (JSONB map of field to ISO time).
- The client sends `base_version`. If it equals the server version, it applies directly. If not, the server merges non-overlapping fields, resolves overlapping fields by the rules above, and returns `merged_fields` and `conflicts` for the client to display.
- Duplicate patient detection uses a blind index (HMAC of normalised ABHA ID or phone) so two workers registering the same patient offline get linked instead of duplicated.
- Clocks on cheap devices drift. Clients send `client_time` and `device_offset_ms` (server time minus device time, learned at last online contact), and the server normalises timestamps.

## 5. Security and privacy (DPDP Act 2023 aligned)

- **Field-level encryption** of name, phone, ABHA ID, address (AES-256-GCM, envelope keys via KMS). Blind indexes allow lookup without decrypting.
- **Explicit consent** captured before any data or image is stored: purpose, language shown, who consented (patient or guardian), and timestamp. Screening endpoints reject records lacking active consent.
- **RBAC:** WORKER sees only own-facility patients. DOCTOR sees assigned review queue. ADMIN sees aggregated data without PII.
- **Audit trail:** every read or write of PII goes to `access_log`. Clinical decisions go to `clinical_audits`.
- **Device security:** IndexedDB blobs are encrypted at rest with a key derived from the worker PIN (WebCrypto). Auto-lock after 5 minutes idle. Remote wipe flag checked on each sync.
- **Data minimisation:** SMS and WhatsApp reminders never contain diagnosis, only "Your eye check-up is due on {date} at {PHC}".
- **Transport:** TLS 1.2+, HSTS, short-lived JWT plus refresh token stored in an httpOnly cookie.

## 6. Referral logic summary

| DR stage | Label | Default action | Timeline |
|---|---|---|---|
| 0 | No DR | Rescreen | Routine, 12 months |
| 1 | Mild NPDR | Rescreen and glycaemic control counselling | Routine, 6 to 12 months |
| 2 | Moderate NPDR | Refer to ophthalmologist | Within 3 months |
| 3 | Severe NPDR | Urgent referral | Within 48 hours |
| 4 | Proliferative DR | Urgent referral | Within 48 hours |

Escalation modifiers (implemented in `risk.py`): low model confidence, HbA1c above 9%, diabetes duration above 10 years, or a symptom flag (sudden vision loss) move the case one tier up. Ungradable images are never reported as "No DR": the worker is told to retake, and after two failed retakes the patient is referred for a manual exam.

## 7. Suggested roadmap for the hackathon demo

1. Day 1: schema, FastAPI skeleton, quality gate, mock model returning stages.
2. Day 2: Grad-CAM with a real checkpoint (train on APTOS 2019 or EyePACS, and report quadratic weighted kappa).
3. Day 3: PWA offline flow and sync demo (toggle airplane mode live).
4. Day 4: doctor dashboard, multilingual strings, PDF report.
5. Day 5: polish, metrics slide (sensitivity at referable DR, calibration), and privacy story.

## 8. Model notes

- EfficientNet-B0 gives the best accuracy per FLOP for this budget. Export the classifier to ONNX for CPU inference (about 40 to 80 ms at 512 px). Grad-CAM runs in PyTorch on only the final feature block.
- Preprocess with Ben Graham style local contrast normalisation for fundus images.
- Calibrate with temperature scaling so the displayed confidence is meaningful.
- Report the operating point for **referable DR (stage 2 or above)**, prioritising sensitivity. Publicly available datasets carry label noise and site bias, so external validation on Indian fundus data matters before any deployment.
