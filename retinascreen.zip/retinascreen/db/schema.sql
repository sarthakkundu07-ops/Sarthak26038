-- RetinaScreen PostgreSQL schema (PostgreSQL 15+)
-- PII columns are stored as ciphertext (bytea) encrypted in the application layer (AES-256-GCM).
-- *_bidx columns are HMAC-SHA256 blind indexes used for equality lookup and duplicate detection.

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ---------- Enums ----------
CREATE TYPE user_role        AS ENUM ('WORKER', 'DOCTOR', 'ADMIN');
CREATE TYPE sex_type         AS ENUM ('FEMALE', 'MALE', 'OTHER', 'UNDISCLOSED');
CREATE TYPE diabetes_type    AS ENUM ('TYPE1', 'TYPE2', 'GESTATIONAL', 'OTHER', 'UNKNOWN');
CREATE TYPE consent_purpose  AS ENUM ('SCREENING', 'DATA_STORAGE', 'TELE_REVIEW', 'REMINDERS', 'RESEARCH');
CREATE TYPE eye_side         AS ENUM ('LEFT', 'RIGHT');
CREATE TYPE screening_status AS ENUM (
  'CAPTURED', 'QC_FAILED', 'SYNCED', 'AI_COMPLETE',
  'REFERRAL_ISSUED', 'DOCTOR_REVIEWED', 'CLOSED'
);
CREATE TYPE referral_urgency AS ENUM ('ROUTINE', 'WITHIN_3_MONTHS', 'IMMEDIATE_48H');
CREATE TYPE referral_status  AS ENUM ('PENDING', 'ACKNOWLEDGED', 'ATTENDED', 'MISSED', 'CANCELLED');
CREATE TYPE audit_verdict    AS ENUM ('AGREE', 'DISAGREE', 'UNGRADABLE');

-- ---------- Facilities ----------
CREATE TABLE facilities (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name         TEXT NOT NULL,
  kind         TEXT NOT NULL CHECK (kind IN ('SUBCENTRE', 'PHC', 'CHC', 'DISTRICT_HOSPITAL')),
  district     TEXT NOT NULL,
  state        TEXT NOT NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- Users ----------
CREATE TABLE users (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  role               user_role NOT NULL,
  full_name_enc      BYTEA NOT NULL,
  phone_enc          BYTEA NOT NULL,
  phone_bidx         BYTEA NOT NULL UNIQUE,
  password_hash      TEXT NOT NULL,                 -- argon2id
  facility_id        UUID REFERENCES facilities(id),
  preferred_language TEXT NOT NULL DEFAULT 'en' CHECK (preferred_language IN ('en', 'hi', 'ta', 'bn')),
  registration_no    TEXT,                          -- NMC / state council number for DOCTOR
  is_active          BOOLEAN NOT NULL DEFAULT TRUE,
  last_login_at      TIMESTAMPTZ,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT doctor_has_reg CHECK (role <> 'DOCTOR' OR registration_no IS NOT NULL)
);

-- ---------- Patients ----------
CREATE TABLE patients (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_uuid        UUID NOT NULL UNIQUE,          -- generated on device, enables idempotent sync
  facility_id        UUID NOT NULL REFERENCES facilities(id),
  registered_by      UUID NOT NULL REFERENCES users(id),

  -- PII (encrypted)
  full_name_enc      BYTEA NOT NULL,
  phone_enc          BYTEA,
  phone_bidx         BYTEA,
  abha_id_enc        BYTEA,                         -- optional 14-digit ABHA
  abha_id_bidx       BYTEA,
  address_enc        BYTEA,

  -- Non-identifying demographics
  birth_year         SMALLINT CHECK (birth_year BETWEEN 1900 AND 2100),
  sex                sex_type NOT NULL DEFAULT 'UNDISCLOSED',
  village_code       TEXT,                          -- LGD code, coarse location only

  -- Diabetic indicators
  diabetes_type      diabetes_type NOT NULL DEFAULT 'UNKNOWN',
  diabetes_duration_years  NUMERIC(4,1) CHECK (diabetes_duration_years >= 0),
  hba1c_percent      NUMERIC(3,1) CHECK (hba1c_percent BETWEEN 3 AND 20),
  hba1c_measured_on  DATE,
  on_insulin         BOOLEAN,
  on_oral_agents     BOOLEAN,
  has_hypertension   BOOLEAN,
  systolic_bp        SMALLINT,
  diastolic_bp       SMALLINT,
  bmi                NUMERIC(4,1),
  is_smoker          BOOLEAN,

  -- Sync and concurrency
  version            INTEGER NOT NULL DEFAULT 1,
  field_ts           JSONB NOT NULL DEFAULT '{}'::jsonb,  -- {"hba1c_percent": "2025-01-01T10:00:00Z", ...}
  conflict_log       JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at         TIMESTAMPTZ                    -- soft delete for erasure requests
);
CREATE INDEX idx_patients_facility  ON patients(facility_id);
CREATE INDEX idx_patients_abha_bidx ON patients(abha_id_bidx) WHERE abha_id_bidx IS NOT NULL;
CREATE INDEX idx_patients_phone_bidx ON patients(phone_bidx) WHERE phone_bidx IS NOT NULL;

-- ---------- Consent ledger (append-only) ----------
CREATE TABLE patient_consents (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id      UUID NOT NULL REFERENCES patients(id),
  purpose         consent_purpose NOT NULL,
  granted         BOOLEAN NOT NULL,                  -- FALSE row = withdrawal
  given_by        TEXT NOT NULL CHECK (given_by IN ('PATIENT', 'GUARDIAN')),
  language_shown  TEXT NOT NULL,
  consent_text_version TEXT NOT NULL,
  captured_by     UUID NOT NULL REFERENCES users(id),
  captured_at     TIMESTAMPTZ NOT NULL,              -- device time normalised to server
  recorded_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_consents_patient ON patient_consents(patient_id, purpose, recorded_at DESC);

-- Latest consent per purpose (used to gate processing).
-- Ordered by when the patient actually decided (captured_at), not when it synced, so an offline
-- "grant" that arrives late cannot overwrite an earlier online withdrawal. On exact ties, withdrawal wins.
CREATE VIEW active_consents AS
SELECT DISTINCT ON (patient_id, purpose) patient_id, purpose, granted, captured_at
FROM patient_consents
ORDER BY patient_id, purpose, captured_at DESC, granted ASC;

-- ---------- Screenings ----------
CREATE TABLE screenings (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_uuid        UUID NOT NULL UNIQUE,
  patient_id         UUID NOT NULL REFERENCES patients(id),
  performed_by       UUID NOT NULL REFERENCES users(id),
  facility_id        UUID NOT NULL REFERENCES facilities(id),
  eye                eye_side NOT NULL,
  captured_at        TIMESTAMPTZ NOT NULL,
  status             screening_status NOT NULL DEFAULT 'SYNCED',

  -- Snapshot of vitals at time of visit (history preserved)
  hba1c_percent      NUMERIC(3,1),
  diabetes_duration_years NUMERIC(4,1),
  on_insulin         BOOLEAN,
  symptom_flags      TEXT[] NOT NULL DEFAULT '{}',   -- e.g. {'SUDDEN_VISION_LOSS','FLOATERS'}

  -- Image
  image_key          TEXT NOT NULL,                  -- object-store key
  image_sha256       CHAR(64) NOT NULL,
  image_bytes        INTEGER NOT NULL,

  -- Quality check
  qc_passed          BOOLEAN,
  qc_metrics         JSONB,                          -- {blur_var, brightness, contrast, fov_ratio}
  qc_reasons         TEXT[] NOT NULL DEFAULT '{}',
  retake_of          UUID REFERENCES screenings(id),

  -- AI output
  model_version      TEXT,
  dr_stage           SMALLINT CHECK (dr_stage BETWEEN 0 AND 4),
  confidence         NUMERIC(5,4),
  class_probs        JSONB,                          -- [p0,p1,p2,p3,p4]
  heatmap_key        TEXT,
  risk_tier          referral_urgency,
  risk_factors       TEXT[] NOT NULL DEFAULT '{}',
  disclaimer_version TEXT,

  version            INTEGER NOT NULL DEFAULT 1,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT ai_fields_together CHECK (
    (dr_stage IS NULL AND confidence IS NULL) OR (dr_stage IS NOT NULL AND confidence IS NOT NULL)
  )
);
CREATE INDEX idx_screenings_patient ON screenings(patient_id, captured_at DESC);
CREATE INDEX idx_screenings_review  ON screenings(risk_tier, status) WHERE status IN ('AI_COMPLETE', 'REFERRAL_ISSUED');

-- ---------- Referrals ----------
CREATE TABLE referrals (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  screening_id      UUID NOT NULL REFERENCES screenings(id),
  patient_id        UUID NOT NULL REFERENCES patients(id),
  urgency           referral_urgency NOT NULL,
  from_facility_id  UUID NOT NULL REFERENCES facilities(id),
  to_facility_id    UUID REFERENCES facilities(id),
  status            referral_status NOT NULL DEFAULT 'PENDING',
  due_by            TIMESTAMPTZ NOT NULL,
  reason            TEXT NOT NULL,
  outcome_notes_enc BYTEA,
  attended_at       TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_referrals_due ON referrals(status, due_by);

-- ---------- Clinical audits (doctor feedback loop) ----------
CREATE TABLE clinical_audits (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  screening_id       UUID NOT NULL REFERENCES screenings(id),
  doctor_id          UUID NOT NULL REFERENCES users(id),
  verdict            audit_verdict NOT NULL,
  ai_stage           SMALLINT NOT NULL,              -- copy at time of review
  doctor_stage       SMALLINT CHECK (doctor_stage BETWEEN 0 AND 4),
  heatmap_useful     BOOLEAN,
  notes_enc          BYTEA,
  next_followup_date DATE,
  is_active_version  BOOLEAN NOT NULL DEFAULT TRUE,  -- newer review supersedes older, none deleted
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT disagree_needs_stage CHECK (verdict <> 'DISAGREE' OR doctor_stage IS NOT NULL)
);
CREATE INDEX idx_audits_screening ON clinical_audits(screening_id);
-- Feeds model re-training / monitoring
CREATE VIEW model_disagreements AS
SELECT screening_id, ai_stage, doctor_stage, created_at
FROM clinical_audits WHERE verdict = 'DISAGREE' AND is_active_version;

-- ---------- Reminders ----------
CREATE TABLE reminders (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id   UUID NOT NULL REFERENCES patients(id),
  referral_id  UUID REFERENCES referrals(id),
  channel      TEXT NOT NULL CHECK (channel IN ('SMS', 'WHATSAPP')),
  template     TEXT NOT NULL,
  send_at      TIMESTAMPTZ NOT NULL,
  sent_at      TIMESTAMPTZ,
  provider_msg_id TEXT,
  status       TEXT NOT NULL DEFAULT 'SCHEDULED' CHECK (status IN ('SCHEDULED', 'SENT', 'FAILED', 'CANCELLED'))
);
CREATE INDEX idx_reminders_due ON reminders(status, send_at) WHERE status = 'SCHEDULED';

-- ---------- Access log (who looked at what) ----------
CREATE TABLE access_log (
  id          BIGSERIAL PRIMARY KEY,
  user_id     UUID REFERENCES users(id),
  action      TEXT NOT NULL,          -- READ_PATIENT, EXPORT_REPORT, DECRYPT_PHONE, ...
  entity      TEXT NOT NULL,
  entity_id   UUID,
  ip          INET,
  request_id  TEXT,
  at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- Generic change trail via trigger ----------
CREATE TABLE change_log (
  id          BIGSERIAL PRIMARY KEY,
  table_name  TEXT NOT NULL,
  row_id      UUID NOT NULL,
  op          TEXT NOT NULL,
  changed_by  UUID,
  old_data    JSONB,          -- encrypted columns remain ciphertext (base64) here
  new_data    JSONB,
  at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE OR REPLACE FUNCTION log_change() RETURNS trigger AS $$
BEGIN
  INSERT INTO change_log(table_name, row_id, op, changed_by, old_data, new_data)
  VALUES (
    TG_TABLE_NAME,
    COALESCE(NEW.id, OLD.id),
    TG_OP,
    NULLIF(current_setting('app.user_id', true), '')::uuid,
    CASE WHEN TG_OP IN ('UPDATE','DELETE') THEN to_jsonb(OLD) END,
    CASE WHEN TG_OP IN ('INSERT','UPDATE') THEN to_jsonb(NEW) END
  );
  RETURN COALESCE(NEW, OLD);
END; $$ LANGUAGE plpgsql;

CREATE TRIGGER trg_patients_log    AFTER INSERT OR UPDATE OR DELETE ON patients
  FOR EACH ROW EXECUTE FUNCTION log_change();
CREATE TRIGGER trg_screenings_log  AFTER INSERT OR UPDATE OR DELETE ON screenings
  FOR EACH ROW EXECUTE FUNCTION log_change();
CREATE TRIGGER trg_referrals_log   AFTER INSERT OR UPDATE OR DELETE ON referrals
  FOR EACH ROW EXECUTE FUNCTION log_change();
CREATE TRIGGER trg_audits_log      AFTER INSERT OR UPDATE OR DELETE ON clinical_audits
  FOR EACH ROW EXECUTE FUNCTION log_change();

-- ---------- Consent gate: no screening without active SCREENING + DATA_STORAGE consent ----------
CREATE OR REPLACE FUNCTION enforce_consent() RETURNS trigger AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM active_consents
    WHERE patient_id = NEW.patient_id AND purpose = 'SCREENING' AND granted
  ) OR NOT EXISTS (
    SELECT 1 FROM active_consents
    WHERE patient_id = NEW.patient_id AND purpose = 'DATA_STORAGE' AND granted
  ) THEN
    RAISE EXCEPTION 'CONSENT_REQUIRED for patient %', NEW.patient_id USING ERRCODE = 'P0001';
  END IF;
  RETURN NEW;
END; $$ LANGUAGE plpgsql;

CREATE TRIGGER trg_screenings_consent BEFORE INSERT ON screenings
  FOR EACH ROW EXECUTE FUNCTION enforce_consent();

-- ---------- Row-level security (facility scoping for workers) ----------
ALTER TABLE patients   ENABLE ROW LEVEL SECURITY;
ALTER TABLE screenings ENABLE ROW LEVEL SECURITY;

-- The app sets: SET LOCAL app.user_id, app.role, app.facility_id per request.
CREATE POLICY patients_scope ON patients USING (
  current_setting('app.role', true) = 'DOCTOR'
  OR facility_id = NULLIF(current_setting('app.facility_id', true), '')::uuid
);
CREATE POLICY screenings_scope ON screenings USING (
  current_setting('app.role', true) = 'DOCTOR'
  OR facility_id = NULLIF(current_setting('app.facility_id', true), '')::uuid
);
-- ADMIN dashboards read from aggregate views only (no PII columns exposed).
CREATE VIEW district_stats AS
SELECT f.district, date_trunc('month', s.captured_at) AS month,
       count(*) AS screenings,
       count(*) FILTER (WHERE s.dr_stage >= 2) AS referable,
       count(*) FILTER (WHERE s.qc_passed IS FALSE) AS qc_failed
FROM screenings s JOIN facilities f ON f.id = s.facility_id
GROUP BY 1, 2;
