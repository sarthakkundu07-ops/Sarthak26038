"""POST /api/screenings/sync : idempotent batch sync for offline field records.

Each operation runs in its own SAVEPOINT, so one bad record never sinks the batch.
Client-supplied AI or doctor fields are ignored (server authoritative).
Screening images travel separately (PUT /api/screenings/{client_uuid}/image) so that a flaky 2G
link only retries the failed blob, not the entire batch.
"""
from __future__ import annotations

import logging
import uuid
from datetime import date, datetime, timedelta, timezone
from typing import Any, Literal, Optional

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError
from sqlalchemy.ext.asyncio import AsyncSession

from . import crypto
from .deps import CurrentUser, get_db, log_access, require_role

log = logging.getLogger("sync")
router = APIRouter(prefix="/api/screenings", tags=["sync"])

# ---- Column whitelists (used to build SQL; never interpolate client keys) ----
PLAIN_FIELDS = {
    "birth_year", "sex", "village_code", "diabetes_type", "diabetes_duration_years",
    "hba1c_percent", "hba1c_measured_on", "on_insulin", "on_oral_agents",
    "has_hypertension", "systolic_bp", "diastolic_bp", "bmi", "is_smoker",
}
PII_FIELDS = {"full_name", "phone", "abha_id", "address"}
SAFETY_FIELDS = {"hba1c_percent", "on_insulin", "diabetes_type"}
DATE_FIELDS = {"hba1c_measured_on"}


# ---------------- Schemas ----------------
class SyncOp(BaseModel):
    entity: Literal["patient", "consent", "screening"]
    client_uuid: uuid.UUID
    base_version: Optional[int] = None         # server version the client last saw (patients)
    client_time: datetime
    data: dict[str, Any]
    field_ts: dict[str, datetime] = Field(default_factory=dict)


class SyncBatch(BaseModel):
    device_id: str = Field(max_length=64)
    device_offset_ms: int = 0                  # server_time - device_time, learned at last online contact
    ops: list[SyncOp] = Field(max_length=20)

    @field_validator("ops")
    @classmethod
    def _not_empty(cls, v):
        if not v:
            raise ValueError("ops must not be empty")
        return v


class OpResult(BaseModel):
    client_uuid: uuid.UUID
    entity: str
    status: Literal["APPLIED", "MERGED", "DUPLICATE_LINKED", "NOOP", "REJECTED"]
    server_id: Optional[uuid.UUID] = None
    server_version: Optional[int] = None
    merged_fields: list[str] = []
    conflicts: list[dict] = []
    needs_image: bool = False
    error_code: Optional[str] = None
    error_message: Optional[str] = None


class SyncResponse(BaseModel):
    results: list[OpResult]
    server_time: datetime


# ---------------- Pure merge logic (unit-testable) ----------------
def normalise_ts(ts: datetime, offset_ms: int, now: datetime) -> datetime:
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=timezone.utc)
    corrected = ts + timedelta(milliseconds=offset_ms)
    return min(corrected, now)  # a device clock in the future must not win every conflict


def merge_patient_fields(
    server_values: dict[str, Any],
    server_field_ts: dict[str, str],
    server_version: int,
    incoming: dict[str, Any],
    incoming_ts: dict[str, datetime],
    base_version: Optional[int],
) -> tuple[dict[str, Any], dict[str, datetime], list[dict]]:
    """Field-level last-writer-wins. Returns (updates, new_ts, conflicts).

    - Field changed only on the client since base_version -> apply.
    - Field changed on both sides -> newer timestamp wins; loser is recorded in `conflicts`.
      Safety-critical fields are flagged needs_confirm so the next worker verifies the value.
    """
    updates: dict[str, Any] = {}
    new_ts: dict[str, datetime] = {}
    conflicts: list[dict] = []
    client_is_stale = base_version is not None and base_version < server_version

    for f, value in incoming.items():
        ts = incoming_ts.get(f)
        s_ts_raw = server_field_ts.get(f)
        s_ts = datetime.fromisoformat(s_ts_raw) if s_ts_raw else None
        same_value = server_values.get(f) == value
        if same_value:
            continue
        if s_ts is None or not client_is_stale:
            updates[f], new_ts[f] = value, ts
            continue
        # Both sides edited this field since the client's base version.
        client_wins = ts is not None and ts > s_ts
        loser_value = server_values.get(f) if client_wins else value
        winner_value = value if client_wins else server_values.get(f)
        if client_wins:
            updates[f], new_ts[f] = value, ts
        conflicts.append({
            "field": f,
            "kept": winner_value,
            "discarded": loser_value,
            "needs_confirm": f in SAFETY_FIELDS,
        })
    return updates, new_ts, conflicts


# ---------------- DB helpers ----------------
def _coerce(field: str, value: Any) -> Any:
    if value is not None and field in DATE_FIELDS and isinstance(value, str):
        return date.fromisoformat(value)
    return value


def _encrypt_pii(data: dict[str, Any]) -> dict[str, Any]:
    """Map plaintext PII keys to encrypted / blind-index column values."""
    cols: dict[str, Any] = {}
    if "full_name" in data:
        cols["full_name_enc"] = crypto.encrypt(data["full_name"], aad=b"patients.full_name")
    if "phone" in data:
        cols["phone_enc"] = crypto.encrypt(data["phone"], aad=b"patients.phone")
        cols["phone_bidx"] = crypto.blind_index(data["phone"])
    if "abha_id" in data:
        cols["abha_id_enc"] = crypto.encrypt(data["abha_id"], aad=b"patients.abha_id")
        cols["abha_id_bidx"] = crypto.blind_index(data["abha_id"])
    if "address" in data:
        cols["address_enc"] = crypto.encrypt(data["address"], aad=b"patients.address")
    return cols


async def _upsert_patient(db: AsyncSession, user: CurrentUser, op: SyncOp,
                          ts: dict[str, datetime], now: datetime) -> OpResult:
    data = op.data
    plain = {k: _coerce(k, v) for k, v in data.items() if k in PLAIN_FIELDS}
    pii_cols = _encrypt_pii({k: v for k, v in data.items() if k in PII_FIELDS})

    row = (await db.execute(
        text("SELECT * FROM patients WHERE client_uuid = :c FOR UPDATE"), {"c": op.client_uuid}
    )).mappings().first()

    # Duplicate detection: same ABHA ID or phone already registered by another device
    if row is None:
        bidx = pii_cols.get("abha_id_bidx") or pii_cols.get("phone_bidx")
        if bidx is not None:
            col = "abha_id_bidx" if pii_cols.get("abha_id_bidx") else "phone_bidx"
            row = (await db.execute(
                text(f"SELECT * FROM patients WHERE {col} = :b AND deleted_at IS NULL FOR UPDATE"),
                {"b": bidx},
            )).mappings().first()
            if row is not None:
                dup_id = row["id"]
                res = await _merge_into(db, row, plain, pii_cols, op, ts)
                res.status, res.server_id = "DUPLICATE_LINKED", dup_id
                return res

    if row is None:
        cols = {**plain, **pii_cols}
        if "full_name_enc" not in cols:
            return OpResult(client_uuid=op.client_uuid, entity="patient", status="REJECTED",
                            error_code="FULL_NAME_REQUIRED", error_message="Patient name is required")
        field_ts = {k: ts.get(k, op.client_time).isoformat() for k in data if k in PLAIN_FIELDS | PII_FIELDS}
        cols.update(client_uuid=op.client_uuid, facility_id=user.facility_id,
                    registered_by=user.id, field_ts=_json(field_ts))
        names = ", ".join(cols)
        params = ", ".join(f":{k}" if k != "field_ts" else "CAST(:field_ts AS jsonb)" for k in cols)
        new_id = (await db.execute(
            text(f"INSERT INTO patients ({names}) VALUES ({params}) RETURNING id, version"), cols
        )).mappings().one()
        return OpResult(client_uuid=op.client_uuid, entity="patient", status="APPLIED",
                        server_id=new_id["id"], server_version=new_id["version"])

    return await _merge_into(db, row, plain, pii_cols, op, ts)


def _json(obj: Any) -> str:
    import json
    return json.dumps(obj, default=str)


def _as_dict(v: Any) -> dict:
    """asyncpg may hand back jsonb as str depending on codec setup."""
    import json
    if v is None:
        return {}
    return json.loads(v) if isinstance(v, str) else dict(v)


async def _merge_into(db: AsyncSession, row, plain: dict, pii_cols: dict,
                      op: SyncOp, ts: dict[str, datetime]) -> OpResult:
    # Facility scope: a worker may only touch patients of their own facility (RLS enforces too).
    server_fts = _as_dict(row["field_ts"])
    updates, new_ts, conflicts = merge_patient_fields(
        server_values={k: row[k] for k in plain},
        server_field_ts=server_fts,
        server_version=row["version"],
        incoming=plain,
        incoming_ts=ts,
        base_version=op.base_version,
    )
    # PII: treat each logical field as a unit (encrypted blobs cannot be compared directly)
    for logical, col in (("full_name", "full_name_enc"), ("phone", "phone_enc"),
                         ("abha_id", "abha_id_enc"), ("address", "address_enc")):
        if col in pii_cols:
            s_ts = server_fts.get(logical)
            c_ts = ts.get(logical, op.client_time)
            if s_ts is None or c_ts > datetime.fromisoformat(s_ts):
                updates[col] = pii_cols[col]
                if col == "phone_enc":
                    updates["phone_bidx"] = pii_cols["phone_bidx"]
                if col == "abha_id_enc":
                    updates["abha_id_bidx"] = pii_cols["abha_id_bidx"]
                new_ts[logical] = c_ts

    if not updates and not conflicts:
        return OpResult(client_uuid=op.client_uuid, entity="patient", status="NOOP",
                        server_id=row["id"], server_version=row["version"])

    merged_ts = {**server_fts, **{k: v.isoformat() for k, v in new_ts.items()}}
    set_parts = [f"{c} = :{c}" for c in updates]  # keys come from whitelists only
    params: dict[str, Any] = {**updates, "id": row["id"], "fts": _json(merged_ts),
                              "clog": _json(conflicts)}
    if conflicts:
        set_parts.append("conflict_log = conflict_log || CAST(:clog AS jsonb)")
    set_parts += ["field_ts = CAST(:fts AS jsonb)", "version = version + 1", "updated_at = now()"]
    upd = (await db.execute(
        text(f"UPDATE patients SET {', '.join(set_parts)} WHERE id = :id RETURNING version"), params
    )).mappings().one()

    logical_changed = [c.removesuffix("_enc") for c in updates if c.endswith("_enc")] + \
                      [c for c in updates if not c.endswith(("_enc", "_bidx"))]
    return OpResult(client_uuid=op.client_uuid, entity="patient",
                    status="MERGED" if conflicts or op.base_version != row["version"] else "APPLIED",
                    server_id=row["id"], server_version=upd["version"],
                    merged_fields=logical_changed, conflicts=conflicts)


async def _insert_consent(db: AsyncSession, user: CurrentUser, op: SyncOp, captured_at: datetime) -> OpResult:
    d = op.data
    pid = (await db.execute(
        text("SELECT id FROM patients WHERE client_uuid = :c"), {"c": uuid.UUID(str(d["patient_client_uuid"]))}
    )).scalar()
    if pid is None:
        return OpResult(client_uuid=op.client_uuid, entity="consent", status="REJECTED",
                        error_code="PATIENT_NOT_SYNCED", error_message="Sync the patient first")
    await db.execute(text("""
        INSERT INTO patient_consents (patient_id, purpose, granted, given_by, language_shown,
                                      consent_text_version, captured_by, captured_at)
        SELECT :p, CAST(:purpose AS consent_purpose), :g, :by, :lang, :ver, :u, :at
        WHERE NOT EXISTS (SELECT 1 FROM patient_consents
                          WHERE patient_id = :p AND purpose = CAST(:purpose AS consent_purpose)
                            AND granted = :g AND captured_at = :at)"""),
        {"p": pid, "purpose": d["purpose"], "g": bool(d["granted"]), "by": d["given_by"],
         "lang": d["language_shown"], "ver": d["consent_text_version"], "u": user.id, "at": captured_at})
    return OpResult(client_uuid=op.client_uuid, entity="consent", status="APPLIED", server_id=pid)


async def _insert_screening(db: AsyncSession, user: CurrentUser, op: SyncOp, captured_at: datetime) -> OpResult:
    d = op.data
    existing = (await db.execute(
        text("SELECT id, status, version FROM screenings WHERE client_uuid = :c"), {"c": op.client_uuid}
    )).mappings().first()
    if existing:   # screenings are immutable once synced; report state so the client can resume
        return OpResult(client_uuid=op.client_uuid, entity="screening", status="NOOP",
                        server_id=existing["id"], server_version=existing["version"],
                        needs_image=existing["status"] == "CAPTURED")
    pid = (await db.execute(
        text("SELECT id FROM patients WHERE client_uuid = :c"), {"c": uuid.UUID(str(d["patient_client_uuid"]))}
    )).scalar()
    if pid is None:
        return OpResult(client_uuid=op.client_uuid, entity="screening", status="REJECTED",
                        error_code="PATIENT_NOT_SYNCED", error_message="Sync the patient first")
    row = (await db.execute(text("""
        INSERT INTO screenings (client_uuid, patient_id, performed_by, facility_id, eye, captured_at,
            status, hba1c_percent, diabetes_duration_years, on_insulin, symptom_flags,
            image_key, image_sha256, image_bytes, qc_passed, qc_metrics, qc_reasons)
        VALUES (:c, :p, :u, :f, CAST(:eye AS eye_side), :at, 'CAPTURED', :hb, :dur, :ins, :sym,
                :key, :sha, :bytes, :qcp, CAST(:qcm AS jsonb), :qcr)
        RETURNING id, version"""), {
        "c": op.client_uuid, "p": pid, "u": user.id, "f": user.facility_id, "eye": d["eye"], "at": captured_at,
        "hb": d.get("hba1c_percent"), "dur": d.get("diabetes_duration_years"), "ins": d.get("on_insulin"),
        "sym": d.get("symptom_flags", []), "key": f"screenings/{op.client_uuid}.jpg",
        "sha": d["image_sha256"], "bytes": int(d["image_bytes"]),
        "qcp": d.get("qc_passed"), "qcm": _json(d.get("qc_metrics") or {}), "qcr": d.get("qc_reasons", []),
    })).mappings().one()
    return OpResult(client_uuid=op.client_uuid, entity="screening", status="APPLIED",
                    server_id=row["id"], server_version=row["version"], needs_image=True)


# ---------------- Endpoint ----------------
@router.post("/sync", response_model=SyncResponse)
async def sync_batch(
    batch: SyncBatch,
    request: Request,
    user: CurrentUser = Depends(require_role("WORKER", "DOCTOR")),
    db: AsyncSession = Depends(get_db),
) -> SyncResponse:
    now = datetime.now(timezone.utc)
    results: list[OpResult] = []
    # Patients first, then consents, then screenings: dependencies within one batch resolve in order.
    order = {"patient": 0, "consent": 1, "screening": 2}
    for op in sorted(batch.ops, key=lambda o: order[o.entity]):
        ts = {k: normalise_ts(v, batch.device_offset_ms, now) for k, v in op.field_ts.items()}
        captured = normalise_ts(op.client_time, batch.device_offset_ms, now)
        try:
            async with db.begin_nested():   # SAVEPOINT per op
                if op.entity == "patient":
                    res = await _upsert_patient(db, user, op, ts, captured)
                elif op.entity == "consent":
                    res = await _insert_consent(db, user, op, captured)
                else:
                    res = await _insert_screening(db, user, op, captured)
                if res.server_id and op.entity == "patient":
                    await log_access(db, user, "SYNC_WRITE_PATIENT", "patient", res.server_id, request)
            results.append(res)
        except DBAPIError as e:
            msg = str(e.orig) if e.orig else str(e)
            code = "CONSENT_REQUIRED" if "CONSENT_REQUIRED" in msg else "DB_ERROR"
            log.warning("sync op %s rejected: %s", op.client_uuid, code)
            results.append(OpResult(
                client_uuid=op.client_uuid, entity=op.entity, status="REJECTED", error_code=code,
                error_message="Patient consent is missing. Record consent first." if code == "CONSENT_REQUIRED"
                else "Could not save this record. It will be retried."))
        except (KeyError, ValueError, TypeError) as e:
            results.append(OpResult(client_uuid=op.client_uuid, entity=op.entity, status="REJECTED",
                                    error_code="BAD_PAYLOAD", error_message=f"Invalid field: {e}"))
    return SyncResponse(results=results, server_time=now)
