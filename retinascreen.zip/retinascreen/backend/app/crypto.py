"""Application-layer field encryption (AES-256-GCM) and blind indexes (HMAC-SHA256).

Keys come from the environment here for the demo. In production fetch a data-encryption key
from a KMS (AWS KMS / HashiCorp Vault / cloud HSM), rotate it, and store the key id in the
ciphertext header so old rows remain decryptable.

Blob layout:  version(1) | nonce(12) | ciphertext+tag
"""
from __future__ import annotations

import hashlib
import hmac
import os
import re
from typing import Optional

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

_VERSION = b"\x01"


def _key(name: str) -> bytes:
    raw = os.environ.get(name)
    if not raw:
        raise RuntimeError(f"{name} is not set")
    key = bytes.fromhex(raw)
    if len(key) != 32:
        raise RuntimeError(f"{name} must be 32 bytes (64 hex chars)")
    return key


def encrypt(plaintext: Optional[str], *, aad: bytes = b"") -> Optional[bytes]:
    """`aad` binds ciphertext to its context (e.g. b'patients.full_name') so blobs cannot be swapped."""
    if plaintext is None or plaintext == "":
        return None
    nonce = os.urandom(12)
    ct = AESGCM(_key("PII_ENC_KEY")).encrypt(nonce, plaintext.encode("utf-8"), aad)
    return _VERSION + nonce + ct


def decrypt(blob: Optional[bytes], *, aad: bytes = b"") -> Optional[str]:
    if not blob:
        return None
    blob = bytes(blob)
    if blob[:1] != _VERSION:
        raise ValueError("unknown ciphertext version")
    nonce, ct = blob[1:13], blob[13:]
    return AESGCM(_key("PII_ENC_KEY")).decrypt(nonce, ct, aad).decode("utf-8")


def blind_index(value: Optional[str]) -> Optional[bytes]:
    """Deterministic keyed hash for equality search and duplicate detection without decrypting."""
    if not value:
        return None
    normalised = re.sub(r"[\s\-]", "", value).lower()
    return hmac.new(_key("PII_INDEX_KEY"), normalised.encode(), hashlib.sha256).digest()


def mask_phone(phone: Optional[str]) -> str:
    if not phone or len(phone) < 4:
        return "****"
    return "******" + phone[-4:]
