"""RetinaScreen API.  Run:  uvicorn app.main:app --workers 2

Env: DATABASE_URL, JWT_SECRET, PII_ENC_KEY (64 hex), PII_INDEX_KEY (64 hex), MODEL_CHECKPOINT (optional)
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import io
import json
import logging
import os
import uuid
from contextlib import asynccontextmanager
from datetime import date
from pathlib import Path
from typing import Optional

from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse, Response
from pydantic import BaseModel, Field, model_validator
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from . import crypto
from .deps import MAX_UPLOAD_BYTES, CurrentUser, get_db, log_access, require_role
from .quality import RETAKE_HINTS, ImageDecodeError, assess_quality, decode_image
from .risk import DISCLAIMER, assess_risk
from .sync import router as sync_router
from .xai import STAGE_NAMES, DRPredictor

log = logging.getLogger("api")
STORAGE_DIR = Path(os.environ.get("BLOB_DIR", "./blobs"))   # swap for S3/MinIO in production
ALLOWED_TYPES = {"image/jpeg", "image/png"}
# Inference is CPU-bound and Grad-CAM registers hooks on shared state: serialise per process.
_infer_lock = asyncio.Lock()


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.predictor = DRPredictor(os.environ.get("MODEL_CHECKPOINT"),
                                      version=os.environ.get("MODEL_VERSION", "effb0-demo"))
    if not os.environ.get("MODEL_CHECKPOINT"):
        log.warning("MODEL_CHECKPOINT not set: running with UNTRAINED weights (demo only)")
    STORAGE_DIR.mkdir(parents=True, exist_ok=True)
    yield


app = FastAPI(title="RetinaScreen API", version="0.1.0", lifespan=lifespan,
              description="AI screening aid; not a definitive clinical diagnosis.")
app.add_middleware(GZipMiddleware, minimum_size=1024)
app.add_middleware(CORSMiddleware, allow_origins=[o for o in os.environ.get("CORS_ORIGINS", "").split(",") if o],
                   allow_methods=["GET", "POST", "PUT"], allow_headers=["*"])
app.include_router(sync_router)


# ---------------- Error handling ----------------
@app.exception_handler(Exception)
async def unhandled(request: Request, exc: Exception):
    rid = uuid.uuid4().hex[:12]
    log.exception("unhandled error rid=%s path=%s", rid, request.url.path)   # never echo internals to clients
    return JSONResponse(status_code=500, content={"error": "INTERNAL_ERROR", "request_id": rid,
                                                  "message": "Something went wrong. Please try again."})


# ---------------- Helpers ----------------
async def read_image_upload(file: UploadFile):
    if file.content_type not in ALLOWED_TYPES:
        raise HTTPException(415, {"error": "UNSUPPORTED_MEDIA", "message": "Upload a JPEG or PNG image."})
    data = await file.read(MAX_UPLOAD_BYTES + 1)
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(413, {"error": "FILE_TOO_LARGE", "message": "Image must be under 8 MB."})
    try:
        return data, decode_image(data)     # decoding validates the bytes, not just the header
    except ImageDecodeError as e:
        raise HTTPException(422, {"error": "BAD_IMAGE", "message": str(e)})


def disclaimer_payload() -> dict:
    return {"version": DISCLAIMER["version"], **{k: v for k, v in DISCLAIMER.items() if k != "version"}}


# ---------------- 1. Quality check ----------------
@app.post("/api/screenings/assess-quality")
async def assess_quality_endpoint(
    image: UploadFile = File(...),
    user: CurrentUser = Depends(require_role("WORKER", "DOCTOR")),
):
    _, img = await read_image_upload(image)
    result = await asyncio.to_thread(assess_quality, img)
    return {
        "passed": result.passed,
        "reasons": result.reasons,
        "hints": {r: RETAKE_HINTS[r] for r in result.reasons if r in RETAKE_HINTS},
        "metrics": result.metrics,
        "disclaimer": disclaimer_payload(),
    }


# ---------------- 2. Inference + Grad-CAM ----------------
class ClinicalContext(BaseModel):
    hba1c_percent: Optional[float] = Field(None, ge=3, le=20)
    diabetes_duration_years: Optional[float] = Field(None, ge=0, le=80)
    on_insulin: Optional[bool] = None
    symptom_flags: list[str] = []


def _run_inference(predictor: DRPredictor, img):
    return predictor.predict(img)


@app.post("/api/screenings/infer")
async def infer(
    request: Request,
    image: UploadFile = File(...),
    hba1c_percent: Optional[float] = Form(None),
    diabetes_duration_years: Optional[float] = Form(None),
    on_insulin: Optional[bool] = Form(None),
    symptom_flags: str = Form(""),
    user: CurrentUser = Depends(require_role("WORKER", "DOCTOR")),
):
    ctx = ClinicalContext(hba1c_percent=hba1c_percent, diabetes_duration_years=diabetes_duration_years,
                          on_insulin=on_insulin,
                          symptom_flags=[s for s in symptom_flags.split(",") if s])
    _, img = await read_image_upload(image)

    qc = await asyncio.to_thread(assess_quality, img)
    if not qc.passed:      # never grade an ungradable image
        return JSONResponse(status_code=422, content={
            "error": "IMAGE_QUALITY_INSUFFICIENT",
            "message": "Image quality is too low for screening. Please retake.",
            "reasons": qc.reasons, "hints": {r: RETAKE_HINTS.get(r, "") for r in qc.reasons},
            "metrics": qc.metrics, "disclaimer": disclaimer_payload(),
        })
    try:
        async with _infer_lock:
            pred = await asyncio.to_thread(_run_inference, request.app.state.predictor, img)
    except Exception:
        log.exception("inference failed")
        raise HTTPException(503, {"error": "INFERENCE_UNAVAILABLE",
                                  "message": "The AI service is temporarily unavailable. "
                                             "Refer per clinical judgment and retry later."})

    risk = assess_risk(pred.stage, pred.confidence, hba1c=ctx.hba1c_percent,
                       duration_years=ctx.diabetes_duration_years, on_insulin=ctx.on_insulin,
                       symptom_flags=ctx.symptom_flags)
    return {
        "model_version": request.app.state.predictor.version,
        "stage": pred.stage,
        "stage_name": pred.stage_name,
        "confidence": pred.confidence,
        "class_probs": dict(zip(STAGE_NAMES, pred.probs)),
        "low_confidence": pred.ungradable_hint,
        "explainability": {
            "method": "grad-cam",
            "target_layer": "features[-1]",
            "overlay_jpeg_base64": pred.heatmap_b64,     # heatmap blended on the retina
            "original_jpeg_base64": pred.original_b64,   # same crop, no overlay (for side-by-side)
            "regions": pred.regions,                      # normalised boxes (0-1) for vector overlays
        },
        "risk": {
            "tier": risk.tier, "refer": risk.refer, "action_code": risk.action_code,
            "due_by": risk.due_by.isoformat() if risk.due_by else None,
            "factors": risk.factors, "next_screening_days": risk.next_screening_days,
        },
        "disclaimer": disclaimer_payload(),
    }


# ---------------- 2b. Image upload for a synced screening (runs inference server-side) ----------------
@app.put("/api/screenings/{client_uuid}/image")
async def upload_screening_image(
    client_uuid: uuid.UUID, request: Request, image: UploadFile = File(...),
    user: CurrentUser = Depends(require_role("WORKER")),
    db: AsyncSession = Depends(get_db),
):
    data, img = await read_image_upload(image)
    row = (await db.execute(text("""
        SELECT id, image_sha256, status, hba1c_percent, diabetes_duration_years, on_insulin, symptom_flags
        FROM screenings WHERE client_uuid = :c"""), {"c": client_uuid})).mappings().first()
    if row is None:
        raise HTTPException(404, {"error": "SCREENING_NOT_SYNCED", "message": "Sync the screening record first."})
    if hashlib.sha256(data).hexdigest() != row["image_sha256"]:
        raise HTTPException(409, {"error": "CHECKSUM_MISMATCH", "message": "Upload was corrupted. Retrying."})
    if row["status"] != "CAPTURED":
        return {"status": row["status"], "note": "already processed"}     # idempotent retry

    key = f"screenings/{client_uuid}.jpg"
    (STORAGE_DIR / key).parent.mkdir(parents=True, exist_ok=True)
    (STORAGE_DIR / key).write_bytes(data)

    qc = await asyncio.to_thread(assess_quality, img)
    if not qc.passed:
        await db.execute(text("""UPDATE screenings SET status='QC_FAILED', qc_passed=false, qc_reasons=:r,
                                 qc_metrics=CAST(:m AS jsonb), version=version+1, updated_at=now()
                                 WHERE id=:id"""),
                         {"r": qc.reasons, "m": json.dumps(qc.metrics), "id": row["id"]})
        return {"status": "QC_FAILED", "reasons": qc.reasons}

    async with _infer_lock:
        pred = await asyncio.to_thread(_run_inference, request.app.state.predictor, img)
    risk = assess_risk(pred.stage, pred.confidence, hba1c=_f(row["hba1c_percent"]),
                       duration_years=_f(row["diabetes_duration_years"]), on_insulin=row["on_insulin"],
                       symptom_flags=list(row["symptom_flags"] or []))
    hkey = f"heatmaps/{client_uuid}.jpg"
    (STORAGE_DIR / hkey).parent.mkdir(parents=True, exist_ok=True)
    (STORAGE_DIR / hkey).write_bytes(base64.b64decode(pred.heatmap_b64))
    # Same crop the model saw, so the original and overlay line up exactly in side-by-side view
    (STORAGE_DIR / hkey.replace(".jpg", "_orig.jpg")).write_bytes(base64.b64decode(pred.original_b64))

    await db.execute(text("""
        UPDATE screenings SET status='AI_COMPLETE', qc_passed=true, qc_metrics=CAST(:qm AS jsonb),
          model_version=:mv, dr_stage=:st, confidence=:cf, class_probs=CAST(:cp AS jsonb),
          heatmap_key=:hk, risk_tier=CAST(:tier AS referral_urgency), risk_factors=:rf,
          disclaimer_version=:dv, version=version+1, updated_at=now()
        WHERE id=:id"""), {
        "qm": json.dumps(qc.metrics), "mv": request.app.state.predictor.version, "st": pred.stage,
        "cf": pred.confidence, "cp": json.dumps(pred.probs), "hk": hkey, "tier": risk.tier,
        "rf": risk.factors, "dv": DISCLAIMER["version"], "id": row["id"]})
    if risk.refer:
        await db.execute(text("""
            INSERT INTO referrals (screening_id, patient_id, urgency, from_facility_id, due_by, reason)
            SELECT s.id, s.patient_id, CAST(:u AS referral_urgency), s.facility_id, :due, :reason
            FROM screenings s WHERE s.id = :id"""),
            {"u": risk.tier, "due": risk.due_by, "reason": ",".join(risk.factors), "id": row["id"]})
    return {"status": "AI_COMPLETE", "stage": pred.stage, "confidence": pred.confidence, "risk_tier": risk.tier}


def _f(v) -> Optional[float]:
    return float(v) if v is not None else None


# ---------------- 3. Doctor review (feedback loop) ----------------
class AuditIn(BaseModel):
    verdict: str = Field(pattern="^(AGREE|DISAGREE|UNGRADABLE)$")
    doctor_stage: Optional[int] = Field(None, ge=0, le=4)
    heatmap_useful: Optional[bool] = None
    notes: Optional[str] = Field(None, max_length=4000)
    next_followup_date: Optional[date] = None

    @model_validator(mode="after")
    def _check(self):
        if self.verdict == "DISAGREE" and self.doctor_stage is None:
            raise ValueError("doctor_stage is required when disagreeing with the AI")
        if self.next_followup_date and self.next_followup_date < date.today():
            raise ValueError("next_followup_date cannot be in the past")
        return self


@app.get("/api/review/queue")
async def review_queue(request: Request, user: CurrentUser = Depends(require_role("DOCTOR")),
                       db: AsyncSession = Depends(get_db)):
    rows = (await db.execute(text("""
        SELECT s.id, s.captured_at, s.dr_stage, s.confidence, s.risk_tier, s.eye
        FROM screenings s
        WHERE s.status IN ('AI_COMPLETE','REFERRAL_ISSUED')
        ORDER BY (s.risk_tier = 'IMMEDIATE_48H') DESC, s.confidence ASC, s.captured_at ASC
        LIMIT 100"""))).mappings().all()          # urgent first, then least-confident AI outputs
    return {"items": [dict(r) for r in rows], "disclaimer": disclaimer_payload()}


@app.get("/api/screenings/{screening_id}")
async def screening_detail(screening_id: uuid.UUID, request: Request,
                           user: CurrentUser = Depends(require_role("WORKER", "DOCTOR")),
                           db: AsyncSession = Depends(get_db)):
    """AI result + both images (original and Grad-CAM overlay) for review. No direct PII returned."""
    s = (await db.execute(text("""
        SELECT id, eye, captured_at, dr_stage, confidence, class_probs, risk_tier, risk_factors,
               hba1c_percent, diabetes_duration_years, on_insulin, symptom_flags,
               image_key, heatmap_key, model_version, status
        FROM screenings WHERE id = :i"""), {"i": screening_id})).mappings().first()
    if s is None or s["dr_stage"] is None:
        raise HTTPException(404, {"error": "NOT_FOUND", "message": "No AI result for this screening yet."})

    def b64(key):
        f = STORAGE_DIR / key if key else None
        return base64.b64encode(f.read_bytes()).decode() if f and f.exists() else None

    await log_access(db, user, "READ_SCREENING", "screening", screening_id, request)
    return {
        "id": s["id"], "eye": s["eye"], "captured_at": s["captured_at"], "status": s["status"],
        "stage": s["dr_stage"], "stage_name": STAGE_NAMES[s["dr_stage"]],
        "confidence": float(s["confidence"]), "risk_tier": s["risk_tier"], "risk_factors": s["risk_factors"],
        "context": {"hba1c_percent": _f(s["hba1c_percent"]), "duration_years": _f(s["diabetes_duration_years"]),
                    "on_insulin": s["on_insulin"], "symptom_flags": s["symptom_flags"]},
        "model_version": s["model_version"],
        "explainability": {
            "original_jpeg_base64": b64(s["heatmap_key"].replace(".jpg", "_orig.jpg") if s["heatmap_key"] else None),
            "overlay_jpeg_base64": b64(s["heatmap_key"]),
        },
        "disclaimer": disclaimer_payload(),
    }


@app.post("/api/screenings/{screening_id}/audit", status_code=201)
async def submit_audit(screening_id: uuid.UUID, body: AuditIn, request: Request,
                       user: CurrentUser = Depends(require_role("DOCTOR")),
                       db: AsyncSession = Depends(get_db)):
    s = (await db.execute(text("SELECT id, dr_stage, patient_id FROM screenings WHERE id=:i FOR UPDATE"),
                          {"i": screening_id})).mappings().first()
    if s is None or s["dr_stage"] is None:
        raise HTTPException(404, {"error": "NOT_FOUND", "message": "No AI result available to review."})
    await db.execute(text("UPDATE clinical_audits SET is_active_version=false WHERE screening_id=:i"),
                     {"i": screening_id})                       # supersede, never delete
    await db.execute(text("""
        INSERT INTO clinical_audits (screening_id, doctor_id, verdict, ai_stage, doctor_stage,
                                     heatmap_useful, notes_enc, next_followup_date)
        VALUES (:s, :d, CAST(:v AS audit_verdict), :ai, :ds, :hu, :n, :f)"""),
        {"s": screening_id, "d": user.id, "v": body.verdict, "ai": s["dr_stage"], "ds": body.doctor_stage,
         "hu": body.heatmap_useful, "n": crypto.encrypt(body.notes, aad=b"clinical_audits.notes"),
         "f": body.next_followup_date})
    await db.execute(text("UPDATE screenings SET status='DOCTOR_REVIEWED', version=version+1 WHERE id=:i"),
                     {"i": screening_id})
    if body.next_followup_date:
        await db.execute(text("""
            INSERT INTO reminders (patient_id, channel, template, send_at)
            SELECT :p, ch, 'FOLLOWUP_DUE', CAST(:d AS date) - 2
            FROM unnest(ARRAY['SMS','WHATSAPP']) AS ch
            WHERE EXISTS (SELECT 1 FROM active_consents WHERE patient_id=:p AND purpose='REMINDERS' AND granted)"""),
            {"p": s["patient_id"], "d": body.next_followup_date})
    await log_access(db, user, "DOCTOR_REVIEW", "screening", screening_id, request)
    return {"status": "recorded", "verdict": body.verdict}


# ---------------- 4. PDF report ----------------
@app.get("/api/screenings/{screening_id}/report.pdf")
async def report_pdf(screening_id: uuid.UUID, request: Request,
                     lang: str = "en", user: CurrentUser = Depends(require_role("WORKER", "DOCTOR")),
                     db: AsyncSession = Depends(get_db)):
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.utils import ImageReader
    from reportlab.pdfgen import canvas

    s = (await db.execute(text("""SELECT id, captured_at, eye, dr_stage, confidence, risk_tier, heatmap_key
                                  FROM screenings WHERE id=:i"""), {"i": screening_id})).mappings().first()
    if s is None or s["dr_stage"] is None:
        raise HTTPException(404, {"error": "NOT_FOUND", "message": "Report not available yet."})
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    w, h = A4
    # NOTE: for Hindi / Bengali / Tamil, register a Noto Sans TTF via pdfmetrics.registerFont
    # and switch fonts per `lang`; the default Helvetica cannot render Indic scripts.
    c.setFont("Helvetica-Bold", 16); c.drawString(40, h - 50, "Diabetic Retinopathy Screening Report")
    c.setFont("Helvetica", 11)
    c.drawString(40, h - 80, f"Screening ID: {s['id']}   Eye: {s['eye']}   Date: {s['captured_at']:%d %b %Y}")
    c.drawString(40, h - 100, f"AI stage: {s['dr_stage']} ({STAGE_NAMES[s['dr_stage']]})   "
                              f"Confidence: {float(s['confidence']):.0%}   Referral: {s['risk_tier']}")
    hk = STORAGE_DIR / (s["heatmap_key"] or "")
    if s["heatmap_key"] and hk.exists():
        c.drawImage(ImageReader(str(hk)), 40, h - 420, width=300, height=300, preserveAspectRatio=True)
    c.setFont("Helvetica-Oblique", 9)
    c.drawString(40, 60, DISCLAIMER["en"])
    c.showPage(); c.save()
    await log_access(db, user, "EXPORT_REPORT", "screening", screening_id, request)
    return Response(buf.getvalue(), media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="dr-report-{s["id"]}.pdf"'})
