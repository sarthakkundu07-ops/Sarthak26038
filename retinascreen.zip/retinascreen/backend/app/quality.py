"""Fast fundus image quality gate (OpenCV). Runs in roughly 20-40 ms on a low-end CPU.

Checks: blur (variance of Laplacian), darkness / overexposure, contrast, and field-of-view
(is a circular retina disc actually present and mostly uncropped?).
Thresholds are starting points. Tune them on your own camera data.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Optional

import cv2
import numpy as np

WORK_SIZE = 512  # analysis resolution; keeps cost predictable regardless of upload size


@dataclass(frozen=True)
class QCThresholds:
    min_blur_var: float = 60.0       # Laplacian variance inside the retina mask (at 512 px)
    min_brightness: float = 35.0     # mean green channel, 0-255
    max_brightness: float = 200.0
    min_contrast: float = 22.0       # std of green channel inside mask
    max_saturated_frac: float = 0.15  # fraction of pixels >= 250 (flash glare)
    min_fov_ratio: float = 0.45      # retina area / image area
    min_circularity: float = 0.72    # 4*pi*A / P^2 of the retina contour (cropped discs score low)
    aspect_range: tuple[float, float] = (0.75, 1.35)  # bounding-box w/h; a side-cropped disc is far from round


@dataclass
class QCResult:
    passed: bool
    reasons: list[str] = field(default_factory=list)      # machine codes, translated in the UI
    metrics: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)


class ImageDecodeError(ValueError):
    pass


def decode_image(data: bytes) -> np.ndarray:
    """Decode bytes to BGR. Raises ImageDecodeError for corrupt or non-image input."""
    if not data:
        raise ImageDecodeError("empty file")
    arr = np.frombuffer(data, dtype=np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        raise ImageDecodeError("not a decodable image")
    if min(img.shape[:2]) < 256:
        raise ImageDecodeError("image too small (min 256 px on the short side)")
    return img


def _resize_keep_aspect(img: np.ndarray, longest: int) -> np.ndarray:
    h, w = img.shape[:2]
    scale = longest / max(h, w)
    if scale >= 1:
        return img
    return cv2.resize(img, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)


def _retina_mask(gray: np.ndarray) -> tuple[np.ndarray, Optional[np.ndarray]]:
    """Segment the bright circular fundus region from the black surround."""
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    _, mask = cv2.threshold(blur, 12, 255, cv2.THRESH_BINARY)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((15, 15), np.uint8))
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return np.zeros_like(gray), None
    largest = max(contours, key=cv2.contourArea)
    clean = np.zeros_like(gray)
    cv2.drawContours(clean, [largest], -1, 255, thickness=cv2.FILLED)
    return clean, largest


def assess_quality(img_bgr: np.ndarray, t: QCThresholds = QCThresholds()) -> QCResult:
    img = _resize_keep_aspect(img_bgr, WORK_SIZE)
    green = img[:, :, 1]  # green channel has the best vessel/lesion contrast in fundus images
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    mask, contour = _retina_mask(gray)
    total_px = mask.size
    mask_px = int(cv2.countNonZero(mask))
    fov_ratio = mask_px / total_px

    reasons: list[str] = []
    metrics: dict = {"fov_ratio": round(fov_ratio, 3)}

    # No retina found at all: stop early, other metrics would be meaningless.
    if contour is None or fov_ratio < 0.10:
        return QCResult(False, ["NO_RETINA_DETECTED"], metrics)

    inside = mask > 0
    g_in = green[inside]

    # --- Field of view / circularity (detects cropped, off-centre or partly hidden discs) ---
    area = cv2.contourArea(contour)
    perim = cv2.arcLength(contour, True)
    circularity = float(4 * np.pi * area / (perim * perim)) if perim > 0 else 0.0
    _, _, bw, bh = cv2.boundingRect(contour)
    aspect = bw / bh if bh else 0.0
    metrics["circularity"] = round(circularity, 3)
    metrics["aspect"] = round(aspect, 2)
    if fov_ratio < t.min_fov_ratio:
        reasons.append("FOV_TOO_SMALL")
    elif circularity < t.min_circularity or not (t.aspect_range[0] <= aspect <= t.aspect_range[1]):
        reasons.append("FOV_CROPPED")

    # --- Brightness ---
    brightness = float(g_in.mean())
    metrics["brightness"] = round(brightness, 1)
    if brightness < t.min_brightness:
        reasons.append("TOO_DARK")
    elif brightness > t.max_brightness:
        reasons.append("TOO_BRIGHT")

    # --- Glare / saturation ---
    sat_frac = float((g_in >= 250).mean())
    metrics["saturated_frac"] = round(sat_frac, 3)
    if sat_frac > t.max_saturated_frac:
        reasons.append("GLARE")

    # --- Contrast ---
    contrast = float(g_in.std())
    metrics["contrast"] = round(contrast, 1)
    if contrast < t.min_contrast:
        reasons.append("LOW_CONTRAST")

    # --- Blur: Laplacian variance restricted to an eroded mask (edge of the disc is a false edge) ---
    eroded = cv2.erode(mask, np.ones((21, 21), np.uint8))
    lap = cv2.Laplacian(green, cv2.CV_64F)
    lap_in = lap[eroded > 0]
    blur_var = float(lap_in.var()) if lap_in.size else 0.0
    metrics["blur_var"] = round(blur_var, 1)
    if blur_var < t.min_blur_var:
        reasons.append("BLURRY")

    return QCResult(passed=not reasons, reasons=reasons, metrics=metrics)


# Guidance shown to the worker; the UI maps each code to a translated string.
RETAKE_HINTS = {
    "NO_RETINA_DETECTED": "Align the camera so the round retina fills the frame.",
    "FOV_TOO_SMALL": "Move closer or dilate the pupil so more retina is visible.",
    "FOV_CROPPED": "Centre the optic disc and avoid eyelid or lash shadow.",
    "TOO_DARK": "Increase illumination or dim the room lights slightly.",
    "TOO_BRIGHT": "Reduce flash intensity.",
    "GLARE": "Tilt the camera slightly to remove the reflection.",
    "LOW_CONTRAST": "Refocus and check for a media haze; retake.",
    "BLURRY": "Hold steady and refocus; ask the patient to fixate on the target.",
}
