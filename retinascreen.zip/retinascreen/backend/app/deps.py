"""Shared FastAPI dependencies: settings, async DB session with RLS context, JWT auth, RBAC."""
from __future__ import annotations

import os
import uuid
from dataclasses import dataclass
from typing import AsyncIterator, Callable

import jwt  # PyJWT
from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

DATABASE_URL = os.environ.get("DATABASE_URL", "postgresql+asyncpg://retina:retina@localhost/retina")
JWT_SECRET = os.environ.get("JWT_SECRET", "")
JWT_ALG = "HS256"
MAX_UPLOAD_BYTES = 8 * 1024 * 1024

engine = create_async_engine(DATABASE_URL, pool_size=10, max_overflow=10, pool_pre_ping=True)
SessionLocal = async_sessionmaker(engine, expire_on_commit=False)
bearer = HTTPBearer(auto_error=False)


@dataclass(frozen=True)
class CurrentUser:
    id: uuid.UUID
    role: str            # WORKER | DOCTOR | ADMIN
    facility_id: uuid.UUID | None


async def get_current_user(
    cred: HTTPAuthorizationCredentials | None = Depends(bearer),
) -> CurrentUser:
    if cred is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Missing credentials")
    if not JWT_SECRET:
        raise HTTPException(status.HTTP_500_INTERNAL_SERVER_ERROR, "Server auth not configured")
    try:
        claims = jwt.decode(cred.credentials, JWT_SECRET, algorithms=[JWT_ALG])
        return CurrentUser(
            id=uuid.UUID(claims["sub"]),
            role=claims["role"],
            facility_id=uuid.UUID(claims["fac"]) if claims.get("fac") else None,
        )
    except (jwt.PyJWTError, KeyError, ValueError):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid or expired token")


def require_role(*roles: str) -> Callable[[CurrentUser], CurrentUser]:
    async def checker(user: CurrentUser = Depends(get_current_user)) -> CurrentUser:
        if user.role not in roles:
            raise HTTPException(status.HTTP_403_FORBIDDEN, "Not permitted for this role")
        return user
    return checker


async def get_db(user: CurrentUser = Depends(get_current_user)) -> AsyncIterator[AsyncSession]:
    """One transaction per request. Sets Postgres session vars used by RLS policies and audit triggers."""
    async with SessionLocal() as session:
        async with session.begin():
            await session.execute(text("SELECT set_config('app.user_id', :u, true)"), {"u": str(user.id)})
            await session.execute(text("SELECT set_config('app.role', :r, true)"), {"r": user.role})
            await session.execute(
                text("SELECT set_config('app.facility_id', :f, true)"),
                {"f": str(user.facility_id) if user.facility_id else ""},
            )
            yield session


async def log_access(db: AsyncSession, user: CurrentUser, action: str, entity: str,
                     entity_id: uuid.UUID | None, request: Request) -> None:
    await db.execute(
        text("""INSERT INTO access_log(user_id, action, entity, entity_id, ip, request_id)
                VALUES (:u, :a, :e, :i, :ip, :rid)"""),
        {"u": user.id, "a": action, "e": entity, "i": entity_id,
         "ip": request.client.host if request.client else None,
         "rid": request.headers.get("x-request-id")},
    )
