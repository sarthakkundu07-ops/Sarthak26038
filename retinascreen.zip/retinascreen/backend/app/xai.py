"""DR classifier (EfficientNet-B0) and Grad-CAM explainability.

Grad-CAM is computed on the final convolutional feature block (`features[-1]` in torchvision's
EfficientNet, a 1280-channel map at stride 32). For a 512 px input that is a 16x16 grid,
upsampled to the image size and blended as a JET heatmap.
"""
from __future__ import annotations

import base64
from dataclasses import dataclass
from typing import Optional

import cv2
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models

INPUT_SIZE = 512
MEAN = np.array([0.485, 0.456, 0.406], dtype=np.float32)
STD = np.array([0.229, 0.224, 0.225], dtype=np.float32)
STAGE_NAMES = ["No DR", "Mild NPDR", "Moderate NPDR", "Severe NPDR", "Proliferative DR"]


def build_model(num_classes: int = 5) -> nn.Module:
    m = models.efficientnet_b0(weights=None)
    m.classifier[1] = nn.Linear(m.classifier[1].in_features, num_classes)
    return m


def load_model(checkpoint_path: Optional[str], device: str = "cpu") -> tuple[nn.Module, float]:
    """Returns (model, temperature). Without a checkpoint you get random weights: DEMO ONLY."""
    model = build_model()
    temperature = 1.0
    if checkpoint_path:
        ckpt = torch.load(checkpoint_path, map_location=device, weights_only=True)
        model.load_state_dict(ckpt["state_dict"])
        temperature = float(ckpt.get("temperature", 1.0))  # fitted on validation logits
    return model.to(device).eval(), temperature


# ---------- Preprocessing ----------
def crop_to_retina(img_bgr: np.ndarray) -> np.ndarray:
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    ys, xs = np.where(gray > 12)
    if len(xs) < 100:
        return img_bgr
    return img_bgr[ys.min(): ys.max() + 1, xs.min(): xs.max() + 1]


def graham_enhance(img_rgb: np.ndarray) -> np.ndarray:
    """Ben Graham local contrast normalisation; widely used for fundus DR models."""
    blurred = cv2.GaussianBlur(img_rgb, (0, 0), sigmaX=INPUT_SIZE / 30)
    return cv2.addWeighted(img_rgb, 4, blurred, -4, 128)


def preprocess(img_bgr: np.ndarray) -> tuple[torch.Tensor, np.ndarray]:
    """Returns the model input tensor (1,3,H,W) and the RGB display image (H,W,3) uint8."""
    cropped = crop_to_retina(img_bgr)
    resized = cv2.resize(cropped, (INPUT_SIZE, INPUT_SIZE), interpolation=cv2.INTER_AREA)
    rgb = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)
    model_in = graham_enhance(rgb).astype(np.float32) / 255.0
    model_in = (model_in - MEAN) / STD
    tensor = torch.from_numpy(model_in.transpose(2, 0, 1)).unsqueeze(0)
    return tensor, rgb


# ---------- Grad-CAM ----------
class GradCAM:
    """Hook-based Grad-CAM on a chosen convolutional layer."""

    def __init__(self, model: nn.Module, target_layer: nn.Module):
        self.model = model
        self._activations: Optional[torch.Tensor] = None
        self._gradients: Optional[torch.Tensor] = None
        self._h1 = target_layer.register_forward_hook(self._save_activation)
        self._h2 = target_layer.register_full_backward_hook(self._save_gradient)

    def _save_activation(self, _m, _inp, out):
        self._activations = out.detach()

    def _save_gradient(self, _m, _gin, gout):
        self._gradients = gout[0].detach()

    def remove(self) -> None:
        self._h1.remove()
        self._h2.remove()

    def __call__(self, x: torch.Tensor, class_idx: Optional[int] = None):
        """Returns (logits, cam in [0,1] with shape (H,W), class_idx used)."""
        self.model.zero_grad(set_to_none=True)
        x = x.requires_grad_(True)  # ensures the graph exists even if early layers are frozen
        logits = self.model(x)
        if class_idx is None:
            class_idx = int(logits.argmax(dim=1))
        logits[0, class_idx].backward()

        acts, grads = self._activations, self._gradients            # (1,C,h,w)
        weights = grads.mean(dim=(2, 3), keepdim=True)              # global-average-pooled gradients
        cam = F.relu((weights * acts).sum(dim=1, keepdim=True))     # (1,1,h,w)
        cam = F.interpolate(cam, size=x.shape[-2:], mode="bilinear", align_corners=False)
        cam = cam[0, 0].cpu().numpy()
        cam -= cam.min()
        cam /= cam.max() + 1e-8
        return logits.detach(), cam, class_idx


def blend_heatmap(rgb: np.ndarray, cam: np.ndarray, alpha: float = 0.45,
                  min_activation: float = 0.25) -> np.ndarray:
    """Blend CAM over the fundus image. Low activations are left transparent so the
    clinician sees the raw retina where the model is not focusing."""
    heat = cv2.applyColorMap((cam * 255).astype(np.uint8), cv2.COLORMAP_JET)
    heat = cv2.cvtColor(heat, cv2.COLOR_BGR2RGB)
    weight = np.where(cam >= min_activation, alpha * cam, 0.0)[..., None]
    out = rgb.astype(np.float32) * (1 - weight) + heat.astype(np.float32) * weight
    return np.clip(out, 0, 255).astype(np.uint8)


def top_regions(cam: np.ndarray, k: int = 3, thresh: float = 0.6) -> list[dict]:
    """Coordinate output for the UI: normalised bounding boxes of the strongest activation blobs."""
    binary = (cam >= thresh).astype(np.uint8)
    n, _, stats, cents = cv2.connectedComponentsWithStats(binary)
    h, w = cam.shape
    regions = []
    for i in range(1, n):  # label 0 is background
        x, y, bw, bh, area = (int(v) for v in stats[i])
        if area < 40:
            continue
        regions.append({
            "x": x / w, "y": y / h, "w": bw / w, "h": bh / h,
            "cx": float(cents[i][0] / w), "cy": float(cents[i][1] / h),
            "score": float(cam[y:y + bh, x:x + bw].max()),
        })
    return sorted(regions, key=lambda r: r["score"], reverse=True)[:k]


def to_base64_jpeg(rgb: np.ndarray, quality: int = 80) -> str:
    ok, buf = cv2.imencode(".jpg", cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR), [cv2.IMWRITE_JPEG_QUALITY, quality])
    if not ok:
        raise RuntimeError("JPEG encoding failed")
    return base64.b64encode(buf.tobytes()).decode("ascii")


# ---------- Public inference API ----------
@dataclass
class Prediction:
    stage: int
    stage_name: str
    confidence: float
    probs: list[float]
    heatmap_b64: str
    original_b64: str
    regions: list[dict]
    ungradable_hint: bool


class DRPredictor:
    def __init__(self, checkpoint: Optional[str] = None, device: str = "cpu", version: str = "effb0-demo"):
        self.device = device
        self.version = version
        self.model, self.temperature = load_model(checkpoint, device)
        # torchvision EfficientNet: features[-1] is the final conv block (1280 channels)
        self.cam = GradCAM(self.model, self.model.features[-1])

    def predict(self, img_bgr: np.ndarray) -> Prediction:
        tensor, rgb = preprocess(img_bgr)
        tensor = tensor.to(self.device)
        logits, cam, _ = self.cam(tensor)                       # explain the predicted class
        probs = F.softmax(logits / self.temperature, dim=1)[0].cpu().numpy()
        stage = int(probs.argmax())
        confidence = float(probs[stage])
        overlay = blend_heatmap(rgb, cam)
        return Prediction(
            stage=stage,
            stage_name=STAGE_NAMES[stage],
            confidence=round(confidence, 4),
            probs=[round(float(p), 4) for p in probs],
            heatmap_b64=to_base64_jpeg(overlay),
            original_b64=to_base64_jpeg(rgb),
            regions=top_regions(cam),
            # Flat probability distribution = model unsure; treated as a risk escalator downstream.
            ungradable_hint=confidence < 0.40,
        )
