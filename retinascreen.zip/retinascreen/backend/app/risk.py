"""Risk stratification and referral mapping.

Base mapping follows the 5-grade international DR scale. Escalators push the tier up one level.
IMPORTANT: thresholds are illustrative. Have them signed off by a clinical lead before deployment.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import IntEnum
from typing import Optional


class Tier(IntEnum):
    ROUTINE = 0
    WITHIN_3_MONTHS = 1
    IMMEDIATE_48H = 2


TIER_LABEL = {
    Tier.ROUTINE: "ROUTINE",
    Tier.WITHIN_3_MONTHS: "WITHIN_3_MONTHS",
    Tier.IMMEDIATE_48H: "IMMEDIATE_48H",
}

TIER_DUE = {
    Tier.ROUTINE: timedelta(days=365),
    Tier.WITHIN_3_MONTHS: timedelta(days=90),
    Tier.IMMEDIATE_48H: timedelta(hours=48),
}

# stage -> (base tier, rescreen interval in days for non-referred cases)
BASE = {
    0: (Tier.ROUTINE, 365),
    1: (Tier.ROUTINE, 180),
    2: (Tier.WITHIN_3_MONTHS, None),
    3: (Tier.IMMEDIATE_48H, None),
    4: (Tier.IMMEDIATE_48H, None),
}

URGENT_SYMPTOMS = {"SUDDEN_VISION_LOSS", "CURTAIN_SHADOW", "NEW_FLOATERS", "EYE_PAIN"}

DISCLAIMER = {
    "version": "2025-01",
    "en": "AI screening aid; not a definitive clinical diagnosis. A qualified eye doctor must confirm any result.",
    "hi": "यह एआई स्क्रीनिंग सहायक है, अंतिम चिकित्सीय निदान नहीं। किसी भी परिणाम की पुष्टि योग्य नेत्र चिकित्सक से करवाएँ।",
    "bn": "এটি একটি এআই স্ক্রিনিং সহায়ক, চূড়ান্ত চিকিৎসা নির্ণয় নয়। যেকোনো ফলাফল যোগ্য চক্ষু চিকিৎসক দ্বারা নিশ্চিত করাতে হবে।",
    "ta": "இது AI ஸ்கிரீனிங் உதவி மட்டுமே; உறுதியான மருத்துவ நோயறிதல் அல்ல. எந்த முடிவையும் தகுதியான கண் மருத்துவர் உறுதிப்படுத்த வேண்டும்.",
}


@dataclass
class RiskAssessment:
    tier: str
    tier_level: int
    due_by: Optional[datetime]
    action_code: str                      # UI maps this to translated text, e.g. REFER_DISTRICT_EYE_HOSPITAL
    refer: bool
    factors: list[str] = field(default_factory=list)
    next_screening_days: Optional[int] = None


def assess_risk(
    stage: int,
    confidence: float,
    *,
    hba1c: Optional[float] = None,
    duration_years: Optional[float] = None,
    on_insulin: Optional[bool] = None,
    symptom_flags: Optional[list[str]] = None,
    now: Optional[datetime] = None,
) -> RiskAssessment:
    if stage not in BASE:
        raise ValueError(f"invalid DR stage: {stage}")
    now = now or datetime.now(timezone.utc)
    tier, rescreen_days = BASE[stage]
    factors: list[str] = [f"STAGE_{stage}"]

    escalate = 0
    if confidence < 0.55:
        escalate += 1
        factors.append("LOW_MODEL_CONFIDENCE")
    if hba1c is not None and hba1c > 9.0:
        escalate += 1
        factors.append("HBA1C_ABOVE_9")
    if duration_years is not None and duration_years > 10:
        escalate += 1
        factors.append("DURATION_OVER_10Y")
    if on_insulin and stage >= 1:
        factors.append("ON_INSULIN")
    urgent = URGENT_SYMPTOMS.intersection(symptom_flags or [])
    if urgent:
        # Sudden vision symptoms bypass the ladder: always urgent regardless of AI stage.
        tier = Tier.IMMEDIATE_48H
        factors.extend(sorted(f"SYMPTOM_{s}" for s in urgent))

    # Escalators only move a case up by ONE tier in total, so a mild case with several
    # soft risk factors does not automatically become an emergency.
    if escalate and tier < Tier.IMMEDIATE_48H:
        tier = Tier(tier + 1)

    refer = tier >= Tier.WITHIN_3_MONTHS
    if tier == Tier.IMMEDIATE_48H:
        action = "REFER_DISTRICT_EYE_HOSPITAL_URGENT"
    elif tier == Tier.WITHIN_3_MONTHS:
        action = "REFER_OPHTHALMOLOGIST_3_MONTHS"
    else:
        action = "RESCREEN_ROUTINE"

    return RiskAssessment(
        tier=TIER_LABEL[tier],
        tier_level=int(tier),
        due_by=(now + TIER_DUE[tier]) if refer else None,
        action_code=action,
        refer=refer,
        factors=factors,
        next_screening_days=None if refer else (rescreen_days or 365),
    )
